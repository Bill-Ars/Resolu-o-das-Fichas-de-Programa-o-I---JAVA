					/*Um programa que cria um arraylist de inteiros. 
					Informe se existem ou nao valores repetidos. Modifique o quinto elemento por um valor x.*/

import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

public class Lista{
	public static void main(String args[]){	
		ArrayList<Integer> L = new ArrayList<>();
		Scanner scanner = new Scanner (System.in);
		
		System.out.println("Quantidade de elementos: ");
		int quant = scanner.nextInt();
		
		for(int i=0; i<quant; i++){
			System.out.println("insira o elemento da lista: ");
			int numero = scanner.nextInt();
			L.add(numero);
			}
			
		System.out.println("Lista final: "+Arrays.toString(L.toArray()));
		
		int cont=0;
		for (int i =0; i<L.size()-1; i++){
			for (int j =i+1; j<L.size(); j++){
				if(L.get(i)==L.get(j)){
					cont++;
				}
			}
		}
		
		if(cont != 0){
			System.out.println ("Possui valores duplicados");
		}else{
			System.out.println("Nao possui valores duplicados");
		}
		
		
		if(L.size() >= 5){
			System.out.println("Insira um valor para a modificar o quinto elemento: ");
			int modificador = scanner.nextInt();
			
			L.set(4, modificador);
		}else{
			System.out.println("Nao possui elemntos suficientes para a modificar");
		}
		
			System.out.println("Lista final: "+Arrays.toString(L.toArray()));
		
		
		
		
		
	}
}