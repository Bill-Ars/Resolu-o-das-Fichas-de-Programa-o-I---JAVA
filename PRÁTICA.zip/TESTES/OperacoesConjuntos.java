/*Escreva um programa que dfina dois  vectores que defina dois vectores A = [2,4,7,13,14,15,16] e B = [1,6,7,11,13,16,18]
e faca as seguintes operacoes de conjuntos:

cria um vector contebndo A U B: Uniao(todos os valores de todos os vectores)
Cria um vector contendo AinterseccaoB: Interseccao(apenas valores que existam em ambos vectores)*/

import java.util.ArrayList;
import java.util.Arrays;

public class OperacoesConjuntos {
    public static void main(String[] args) {
        // Definindo os vetores A e B
        int[] A = {2, 4, 7, 13, 14, 15, 16};
        int[] B = {1, 6, 7, 11, 13, 16, 18};

        // União: A U B
        ArrayList<Integer> uniao = new ArrayList<>();

        // Adiciona todos os elementos do vetor A
        for(int i=0; i<A.length; i++){
			uniao.add(A[i]);
		}

        // Adiciona todos os elementos do vetor B
         for(int i=0; i<B.length; i++){
			uniao.add(B[i]);
		}
		
			
			
        // Interseção: A ∩ B
        ArrayList<Integer> intersecao = new ArrayList<>();

        // Adiciona apenas os elementos que estão em ambos os vetores
        for(int i=0; i<A.length; i++){
				for(int j=0; j<B.length; j++){
					if(A[i] == B[j]){
						intersecao.add(A[i]);
					}
					
					
				}
				
			}
               
        // Exibindo os resultados
        System.out.println("União (A U B): " + Arrays.toString(uniao.toArray()));
        System.out.println("Interseção (A ∩ B): " + Arrays.toString(intersecao.toArray()));
    }
}