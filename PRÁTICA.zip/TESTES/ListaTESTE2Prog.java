                  /*Um programa que cria um arraylist de 15 elementos.  
				  Nesse ArrayList informe se existe um valor x informado pelo usuario.
				  Modifique todos os elemntos superiores ao valor y pelo valor z.
				*/
				
				
				// OPCAO 1

		/*import java.util.Scanner;
		import java.util.ArrayList;
		import java.util.Arrays;

		public class ListaTESTE2Prog{
			public static void main(String[] args) {
				// Criação do ArrayList
				ArrayList<Integer> L = new ArrayList<>();
				Scanner scanner = new Scanner(System.in);
				
				// Solicitar ao usuário que insira 15 números inteiros
				System.out.println("Insira 15 elementos para o ArrayList:");
				for (int i = 0; i < 15; i++) {
					System.out.print("Elemento " + (i + 1) + ": ");
					int numero = scanner.nextInt();
					L.add(numero);
				}
				
				// Exibir a lista final após a inserção
				System.out.println("Lista final: " + Arrays.toString(L.toArray()));
				
				// Verificar se existe um valor x informado pelo usuário
				System.out.print("Digite o valor a ser pesquisado (x): ");
				int x = scanner.nextInt();
				
				boolean existe = false; // Flag para verificar se x existe
				for (int i = 0; i<L.size(); i++){
					if (L.get(i) == x) {
						existe = true;
						break; // Sai do loop se encontrar o valor
					}
				}

				if (existe) {
					System.out.println("O valor " + x + " existe no ArrayList.");
				} else {
					System.out.println("O valor " + x + " não existe no ArrayList.");
				}

				// Substituir todos os elementos superiores a y por z
				System.out.print("Digite o valor limite (y): ");
				int y = scanner.nextInt();
				
				System.out.print("Digite o novo valor (z) para substituir os valores superiores a y: ");
				int z = scanner.nextInt();

				for (int i = 0; i < L.size(); i++) {
					if (L.get(i) > y) {
						L.set(i, z); // Substitui o valor
					}
				}

				// Exibir o ArrayList modificado
				System.out.println("ArrayList modificado: " + Arrays.toString(L.toArray()));
				
				scanner.close(); // Fecha o scanner para evitar vazamento de recursos
			}
		}
		
		*/
		
		
		//  OPCAO 2
		
		
		// OU PODE SER ESCRITO ASSIM:
		
		import java.util.Scanner;
		import java.util.ArrayList;
		import java.util.Arrays;

		public class ListaTESTE2Prog{
			public static void main(String[] args) {
				// Criação do ArrayList
				ArrayList<Integer> L = new ArrayList<>();
				Scanner scanner = new Scanner(System.in);
				
				// Solicitar ao usuário que insira 15 números inteiros
				System.out.println("Insira 15 elementos para o ArrayList:");
				for (int i = 0; i < 15; i++) {
					System.out.print("Elemento " + (i + 1) + ": ");
					int numero = scanner.nextInt();
					L.add(numero);
				}
				
				// Exibir a lista final após a inserção
				System.out.println("Lista final: " + Arrays.toString(L.toArray()));
				
				// Verificar se existe um valor x informado pelo usuário
				System.out.print("Digite o valor a ser pesquisado (x): ");
				int x = scanner.nextInt();
				
				// Flag para verificar se x existe
				for (int i = 0; i<L.size(); i++){
					if (L.get(i) == x) {
						System.out.println("O valor " + x + " existe no ArrayList.");
				}else{
					System.out.println("O valor " + x + " não existe no ArrayList.");
				}

	

				// Substituir todos os elementos superiores a y por z
				System.out.print("Digite o valor limite (y): ");
				int y = scanner.nextInt();
				
				System.out.print("Digite o novo valor (z) para substituir os valores superiores a y: ");
				int z = scanner.nextInt();

				for (int i = 0; i < L.size(); i++) {
					if (L.get(i) > y) {
						L.set(i, z); // Substitui o valor
					}
				}

				// Exibir o ArrayList modificado
				System.out.println("ArrayList modificado: " + Arrays.toString(L.toArray()));
				
				scanner.close(); // Fecha o scanner para evitar vazamento de recursos
			}
		}