import java.util.Random;
import java.util.Scanner;

public class Loteria2{
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Random rnd = new Random();

              System.out.print("Insira o valor mínimo do intervalo: ");
        int min = ler.nextInt();
        System.out.print("Insira o valor máximo do intervalo: ");
        int max = ler.nextInt();

                while (max <= min) {
            System.out.println("O valor máximo deve ser maior que o mínimo.");
            System.out.print("Insira novamente o valor máximo: ");
            max = ler.nextInt();
        }

        int[] numeros = new int[6]; // Ivan, Swiley, Miracle, Bill, Hegel

        for(int i=0;i<numeros.length;i++){
            int numero = rnd.nextInt(min,max+1);
              numeros[i] = numero;
                }
            
        

        System.out.print("Cartão da loteria: ");
        for (int i = 0; i < 5; i++) {
            System.out.print(numeros[i] + " ");
        }
        System.out.println("Número chave: " + numeros[5]);
    }
}

