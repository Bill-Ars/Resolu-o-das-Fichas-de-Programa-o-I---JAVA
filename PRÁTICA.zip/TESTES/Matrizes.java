/*Escfreva um programa em java que leia duas matrizes de inteiros. O programa indica se as duas matrizes sao iguais
ou diferentes. Se forem diferentes deve indicar quantos valores sao diferentes*/

import java.util.Scanner;
import java.util.Arrays;


public class Matrizes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leitura das dimensões da matriz
        System.out.print("Número de linhas: ");
        int linhas = scanner.nextInt();

        System.out.print("Número de colunas: ");
        int colunas = scanner.nextInt();

        // Declaração das matrizes
        int[][] MatrizA = new int[linhas][colunas];
        int[][] MatrizB = new int[linhas][colunas];

        // Leitura da primeira matriz
        System.out.println("Insira os valores da primeira matriz:");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print("MatrizA[" + i + "][" + j + "]: ");
                MatrizA[i][j] = scanner.nextInt();
            }
        }

        // Leitura da segunda matriz
        System.out.println("Insira os valores da segunda matriz:");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print("MatrizB[" + i + "][" + j + "]: ");
                MatrizB[i][j] = scanner.nextInt();
            }
        }

        // Comparação das matrizes
        boolean iguais = true;
        int contDiferentes = 0;

        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (MatrizA[i][j] != MatrizB[i][j]) {
                    iguais = false;
                    contDiferentes++;
                }
            }
        }

        // Resultado da comparação
        if (iguais) {
            System.out.println("As duas matrizes são iguais.");
        } else {
            System.out.println("As duas matrizes são diferentes.");
            System.out.println("Número de valores diferentes: " + contDiferentes);
        }

        scanner.close();
    }
}