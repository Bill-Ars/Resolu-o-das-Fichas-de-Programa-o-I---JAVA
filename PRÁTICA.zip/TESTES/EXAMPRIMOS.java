/*Programa em java que permita de ppreencher 
um vector com numeros aleatorios positivos e negativos. 
Desse vector informar os que sao primos.*/

import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

public class EXAMPRIMOS{
	public static void main (String args[]){
		Scanner scanner = new Scanner (System.in);
		Random random = new Random();
		
		System.out.println("Insira o tamanho: ");
		int n = scanner.nextInt();
		
		int V[] = new int [n];
		
		for(int i=0; i<V.length; i++){
			V[i] = random.nextInt();
		}
		
		   boolean Primo = true;
		for(int i=0; i<V.length; i++){
			if(V[i]<=1){
				Primo = false;
			}else{
				
				for (int k=2; k<Math.sqrt(V[i]); k++){
					if(V[i]%k==0){
						Primo = false;
						break;
					}
					
				}
			}
			
			
			if(Primo){
				System.out.println(V[i]+"e primo.");
			}
		
			
			
			
		}
			
			
			
			
			
			
		
		
		
		
		
		
		
	}
}