/*Programa que permite de preencher um vector 
com os  alores da serie:    E = 1 + 1/2 + 1/4 + 1/8....*/

import java.util.Scanner;
import java.util.Arrays;

public class SerieE {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar ao usuário o número de termos da série
        System.out.print("Insira o número de termos da série E: ");
        int numTermos = scanner.nextInt();

        // Criar um vetor para armazenar os valores da série
        double[] serieE = new double[numTermos];

        // Preencher o vetor com os valores da série
        for (int i = 0; i < numTermos; i++) {
            serieE[i] = 1.0 / Math.pow(2, i); // Calcula 1/(2^i)
        }

        // Exibir os valores da série
        System.out.println("Valores da série E:");
        System.out.println(Arrays.toString(serieE));

        // Fechar o scanner
        scanner.close();
    }
}

