import java.util.Arrays;

public class MediaArrays{
 public static void main(String[]args){
		
		int V[] = {2,4,10,1,3};
		int Soma = 0;
		int contador = 0;
		
		for (int i = 0; i < V.length; i++){
		
		Soma += V[i];
		contador ++;
		}
		
		double Media = Soma/contador;
		
		System.out.println("Media: "+Media);
	}
 }