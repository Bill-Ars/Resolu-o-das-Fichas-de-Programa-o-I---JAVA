
/* Elabore um método Java que tenha como parâmetros de entrada duas matrizes de números 
reais e forneça como resposta o produto das mesmas. Caso não seja possível efetuar a 
multiplicação, o Método deve retornar um código de erro. Caso as dimensões não permitam 
que se efetue a multiplicação o método deve retornar o código de erro diferente de zero. */



import java.util.Scanner;

public class MultiplicacaoMatrizes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Entrada para a primeira matriz
        System.out.println("Digite o número de linhas da primeira matriz:");
        int linhasA = scanner.nextInt();
        System.out.println("Digite o número de colunas da primeira matriz:");
        int colunasA = scanner.nextInt();
        
        double[][] matrizA = new double[linhasA][colunasA];
        System.out.println("Digite os elementos da primeira matriz:");
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasA; j++) {
                matrizA[i][j] = scanner.nextDouble();
            }
        }

        // Entrada para a segunda matriz
        System.out.println("Digite o número de linhas da segunda matriz:");
        int linhasB = scanner.nextInt();
        System.out.println("Digite o número de colunas da segunda matriz:");
        int colunasB = scanner.nextInt();

        double[][] matrizB = new double[linhasB][colunasB];
        System.out.println("Digite os elementos da segunda matriz:");
        for (int i = 0; i < linhasB; i++) {
            for (int j = 0; j < colunasB; j++) {
                matrizB[i][j] = scanner.nextDouble();
            }
        }

        // Verifica se a multiplicação é possível
        if (colunasA != linhasB) {
            System.out.println("Erro: As dimensões não permitem a multiplicação.");
            return; // Retorna com código de erro
        }

        // Inicializa a matriz resultado
        double[][] resultado = new double[linhasA][colunasB];

        // Realiza a multiplicação das matrizes
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasB; j++) {
                resultado[i][j] = 0; // Inicializa o elemento
                for (int k = 0; k < colunasA; k++) { // Loop para calcular o produto
                    resultado[i][j] += matrizA[i][k] * matrizB[k][j];
                }
            }
        }

        // Exibe a matriz resultado
        System.out.println("Resultado da multiplicação das matrizes:");
        for (int i = 0; i < linhasA; i++) {
            for (int j = 0; j < colunasB; j++) {
                System.out.print(resultado[i][j] + " ");
            }
            System.out.println();
        }

        scanner.close(); // Fecha o scanner
    }
}