/*Faça um programa em Linguagem java que leia uma matriz 6 x 6, conte e escreva quantos 
valores maiores que 10 ela possui.*/

import java.util.Scanner;

public class MatrizValoresNumero6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Criação da matriz 6x6
        int[][] matriz = new int[6][6];

        // Leitura dos valores da matriz
        System.out.println("Digite os elementos da matriz 6x6:");
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }

        // Contagem de valores maiores que 10
        int contador = 0;
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (matriz[i][j] > 10) {
                    contador++;
                }
            }
        }

        // Exibição do resultado
        System.out.println("A matriz possui " + contador + " valores maiores que 10.");

        scanner.close(); // Fecha o scanner
    }
}