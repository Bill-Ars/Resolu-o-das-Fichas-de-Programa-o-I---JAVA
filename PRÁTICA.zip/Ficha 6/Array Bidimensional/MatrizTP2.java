/*Elabore um programa em java que preecnhe um array bidimensional com numeros 
aleatorios no intervalo de 15 a 45. E desse array bidimensionsal crie um array unidimensional 
contendo apenas os numeros impares.*/

import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

public class MatrizTP2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random(); // Instância de Random para gerar números aleatórios

        System.out.println("Insira o número de linhas da matriz: ");
        int linhas = scanner.nextInt();
        System.out.println("Insira o número de colunas da matriz: ");
        int colunas = scanner.nextInt();

        int[][] V = new int[linhas][colunas];

        // Preenchendo a matriz com números aleatórios entre 15 e 45
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                V[i][j] = random.nextInt(31) + 15; // Gera números entre 15 e 45
            }
        }

        // Contando quantos números ímpares existem na matriz
        int cont = 0;
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (V[i][j] % 2 != 0) {
                    cont++;
                }
            }
        }

        // Criando um novo array para armazenar os números ímpares
        int[] Novo = new int[cont];
        int k = 0;

        // Preenchendo o array unidimensional com os números ímpares
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (V[i][j] % 2 != 0) {
                    Novo[k] = V[i][j]; // Corrigido para atribuir o valor ao array Novo
                    k++;
                }
            }
        }

        // Exibindo os números ímpares
        System.out.println("Os ímpares são: ");
        System.out.println(Arrays.toString(Novo));

        // Fechando o scanner
        scanner.close();
    }
}