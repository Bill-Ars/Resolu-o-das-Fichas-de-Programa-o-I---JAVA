/*Crie um programa que permite de determinar a soma dos valores de duas matrizes.*/

import java.util.Scanner;

public class SomaMatrizes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Cria duas matrizes 3x3
        int[][] matrizA = new int[3][3];
        int[][] matrizB = new int[3][3];
        int[][] soma = new int[3][3];

        // Lê os elementos da primeira matriz
        System.out.println("Digite os elementos da matriz A (3x3):");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.printf("Elemento A[%d][%d]: ", i, j);
                matrizA[i][j] = scanner.nextInt();
            }
        }

        // Lê os elementos da segunda matriz
        System.out.println("Digite os elementos da matriz B (3x3):");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.printf("Elemento B[%d][%d]: ", i, j);
                matrizB[i][j] = scanner.nextInt();
            }
        }

        // Calcula a soma das duas matrizes
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                soma[i][j] = matrizA[i][j] + matrizB[i][j];
            }
        }

        // Exibe o resultado da soma
        System.out.println("\nResultado da soma das matrizes A e B:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.printf("%d ", soma[i][j]);
            }
            System.out.println(); // Nova linha após cada linha da matriz
        }

        // Fecha o scanner
        scanner.close();
    }
}