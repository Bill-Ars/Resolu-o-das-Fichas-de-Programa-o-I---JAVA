/* Escreva um método que determine a nota média, a nota mais alta e a nota
mínima, sabendo que as notas estão armazenadas num dado array; */

 import java.util.Scanner;
 
 public class Exemplo2UsandoArrayDimens{
	 public static void main(String args[]){
		 Scanner scanner = new Scanner(System.in);
		 
		System.out.println("linhas: ");
		int m = scanner.nextInt();
		
		System.out.println("colunas: ");
		int n = scanner.nextInt();
		
		int Notas [] [] = new int [m] [n];
		
		for (int i =0; i<Notas.length; i++){
			for (int j =0; j<Notas[i].length; j++){
				System.out.println("Insira a nota: ");
				Notas [i] [j] = scanner.nextInt();
			}
		}
		
		// So para me mostrar a minha matriz kkkkk
		javacjavaj
		for (int i =0; i<Notas.length; i++){
			for (int j =0; j<Notas [i].length; j++){
				System.out.print(Notas [i] [j]+" ");
			}
			
			System.out.println();
		}
		
		int Soma = 0;
		int cont = 0;
		
		for (int i =0; i<Notas.length; i++){
			for (int j =0; j<Notas [i].length; j++){
				
				Soma += Notas [i] [j];
				cont++;
			}
		}
		
		double Media = (double)Soma/cont;
		System.out.println("Media das notas: "+Media);
		
		int MaiorNota = Notas[0][0];
		
		for (int i = 0;  i< Notas.length; i++){
			for (int j =0; j < Notas[i].length; j++){
				
				if(MaiorNota<Notas [i][j]){
					MaiorNota = Notas [i][j];
				}
				
			}
		}
		
		System.out.println("A maior nota e: "+MaiorNota);
		
		int MenorNota = Notas[0][0];
		for (int i =0; i<Notas.length; i++){
			for (int j =0; j<Notas[i].length; j++){
				
				if(MenorNota>Notas[i][j]){
					MenorNota = Notas [i][j];
				}
				
			}
		}
		
		System.out.println("A menor nota e: "+MenorNota);
		
	}
 }
		
		
		
		
		
		
		