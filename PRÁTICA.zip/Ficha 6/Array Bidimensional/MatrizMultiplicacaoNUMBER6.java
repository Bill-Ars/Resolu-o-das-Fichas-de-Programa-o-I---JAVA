import java.util.Scanner;

public class MatrizMultiplicacaoNUMBER6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Cria uma matriz 3x3
        int[][] matriz = new int[3][3];

        // Lê os elementos da matriz
        System.out.println("Digite os elementos da matriz 3x3:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.printf("Elemento [%d][%d]: ", i, j);
                matriz[i][j] = scanner.nextInt();
            }
        }

        // Multiplica cada elemento por 5 e imprime o resultado
        System.out.println("\nMatriz após multiplicar cada elemento por 5:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int resultado = matriz[i][j] * 5;
                System.out.printf("%d ", resultado);
            }
            System.out.println(); // Nova linha após cada linha da matriz
        }

        // Fecha o scanner
        scanner.close();
    }
}