/*Escreva um método que determine a nota média, a nota mais alta e a nota
mínima, sabendo que as notas estão armazenadas num dado array;*/

 import java.util.Scanner;
 
 public class Exemplo2UsandoArrayUnid{
	 public static void main(String args[]){
		 Scanner scanner = new Scanner(System.in);
		 
		System.out.println("Insira o tamanho do Array: ");
		int tamanho = scanner.nextInt();
		
		int V [] = new int [tamanho];
		
		for (int i = 0; i<V.length; i++){
			System.out.println("Insira  a nota: ");
		     V[i] = scanner.nextInt();
		}
		
		int Soma = 0;
		int cont = 0;
		
		for (int i = 0; i<V.length; i++){
			Soma += V[i];
			cont ++;
		}
		
		double Media = Soma/cont;
		
		System.out.println("Media: "+Media);
		
		int MaximaNota = V[0];
		for (int i = 0; i<V.length; i++){
			if(MaximaNota<V[i]){
				MaximaNota = V[i];
			}
		}	
			
		System.out.println("A nota mais alta: "+MaximaNota);
		
		int MinimaNota = V[0];
		for (int i = 0; i<V.length; i++){
			if(MinimaNota>V[i]){
				MinimaNota = V[i];
			}
		}
		
		System.out.println("A nota minima: "+MinimaNota);
		
		
	 }
 }
