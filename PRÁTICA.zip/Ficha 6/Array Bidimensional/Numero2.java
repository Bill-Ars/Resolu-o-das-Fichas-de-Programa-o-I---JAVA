/*Elabore um programa que preencha uma matriz com números aleatórios positivos menores 
que 100.*/

import java.util.Random;
import java.util.Scanner;

public class Numero2{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Solicita ao usuário as dimensões da matriz
        System.out.println("Digite o número de linhas da matriz:");
        int linhas = scanner.nextInt();
        System.out.println("Digite o número de colunas da matriz:");
        int colunas = scanner.nextInt();

        // Cria a matriz
        int[][] matriz = new int[linhas][colunas];

        // Preenche a matriz com números aleatórios positivos menores que 100
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                matriz[i][j] = random.nextInt(100); // Números aleatórios entre 0 e 99
            }
        }

        // Exibe a matriz
        System.out.println("Matriz preenchida com números aleatórios:");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println(); // Nova linha após cada linha da matriz
        }

        scanner.close(); // Fecha o scanner
    }
}