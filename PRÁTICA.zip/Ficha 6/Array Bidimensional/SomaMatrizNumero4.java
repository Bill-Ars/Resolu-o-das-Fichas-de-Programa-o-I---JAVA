/*Crie um programa que receba valores do usuário para preencher uma matriz, e em seguida, 
exiba a soma dos valores dela e a soma dos valores da primeira diagonal,ou seja, diagonal 
principal.
*/


import java.util.Scanner;

public class SomaMatrizNumero4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita as dimensões da matriz
        System.out.println("Digite o número de linhas da matriz:");
        int linhas = scanner.nextInt();
        System.out.println("Digite o número de colunas da matriz:");
        int colunas = scanner.nextInt();

        // Cria a matriz
        double[][] matriz = new double[linhas][colunas];

        // Preenche a matriz com valores fornecidos pelo usuário
        System.out.println("Digite os elementos da matriz:");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                matriz[i][j] = scanner.nextDouble();
            }
        }
		


        // Calcula a soma dos valores da matriz e a soma da diagonal principal
        double somaTotal = 0;
        

        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                somaTotal += matriz[i][j]; // Soma todos os elementos
            }
        }
		
		double somaDiagonal = 0;
		for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
			  // Verifica se está na diagonal principal
			 if (i == j) {
                    somaDiagonal += matriz[i][j]; // Soma os elementos da diagonal principal
                }	
				
			}
		}

        // Exibe os resultados
        System.out.println("A soma de todos os valores da matriz é: " + somaTotal);
        System.out.println("A soma dos valores da diagonal principal é: " + somaDiagonal);

        scanner.close(); // Fecha o scanner
    }
}