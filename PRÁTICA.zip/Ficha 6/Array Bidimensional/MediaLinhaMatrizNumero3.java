 /*Criem um programa que possui um método que recebe uma matriz e uma número que 
representa uma linha, o método deve retornar a média dos valores da linha indicada.*/

import java.util.Scanner;

public class MediaLinhaMatrizNumero3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita as dimensões da matriz
        System.out.println("Digite o número de linhas da matriz:");
        int linhas = scanner.nextInt();
        System.out.println("Digite o número de colunas da matriz:");
        int colunas = scanner.nextInt();

        // Cria a matriz
        double[][] matriz = new double[linhas][colunas];

        // Preenche a matriz com valores fornecidos pelo usuário
        System.out.println("Digite os elementos da matriz:");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                matriz[i][j] = scanner.nextDouble();
            }
        }

        // Solicita o número da linha para calcular a média
        System.out.println("Digite o número da linha para calcular a média (0 a " + (linhas - 1) + "):");
        int linhaEscolhida = scanner.nextInt();

        // Verifica se a linha escolhida é válida
        if (linhaEscolhida < 0 || linhaEscolhida >= linhas) {
            System.out.println("Erro: Linha inválida.");
        } else {
            // Calcula a média da linha escolhida
            double soma = 0;
            for (int j = 0; j < colunas; j++) {
                soma += matriz[linhaEscolhida][j];
            }
            double media = soma / colunas;
            System.out.println("A média dos valores da linha " + linhaEscolhida + " é: " + media);
        }

        scanner.close(); // Fecha o scanner
    }
}

