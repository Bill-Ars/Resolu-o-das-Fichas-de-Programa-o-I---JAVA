/* 1) Considere o seguinte array:
a) Diga qual é o tamanho do array?
b) Crie um programa que copia apenas a 2ª linha deste array para um
array unidimensional;
c) No mesmo programa imprima todos os elementos da 2ª linha;
d) No mesmo programa indentifique o maior elemento do array
bidimensional; */

import java.util.Scanner;

public class ArrayOperationsExemPloAula7 {
    public static void main(String[] args) {
        // Definindo o array bidimensional
        int[][] array = {{-4, 7, 2, 0}, {1, 0, 6, -3}, {3, 2, 3, -1}};

        // a) Tamanho do array
        System.out.println("Tamanho do array: " + array.length + " linhas e " + array[0].length + " colunas.");

        // b) Copiando a 2ª linha para um array unidimensional
		// c) Imprimindo todos os elementos da 2ª linha
        
        int[] segundaLinha = new int[array[1].length];
        for (int i = 0; i < array[1].length; i++) {
            segundaLinha[i] = array[1][i];
			System.out.println(segundaLinha[i]);
        }

        
        }
        System.out.println();

        // d) Identificando o maior elemento do array bidimensional
        int maiorElemento = array[0][0]; // Inicializa com o primeiro elemento
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                if (array[i][j] > maiorElemento) {
                    maiorElemento = array[i][j];
                }
            }
        }
        System.out.println("O maior elemento do array bidimensional é: " + maiorElemento);
	}
}