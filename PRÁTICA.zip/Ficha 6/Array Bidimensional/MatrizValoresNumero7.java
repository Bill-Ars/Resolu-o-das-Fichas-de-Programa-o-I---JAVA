/*Crie um programa que recebe uma matriz de inteiros positivos e substitui seus elementos 
de valor ímpar por -1 e os pares por +1.*/

 import java.util.Scanner;

public class MatrizValoresNumero7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		System.out.println("Digite o número de linhas da matriz:");
        int linhas = scanner.nextInt();
        System.out.println("Digite o número de colunas da matriz:");
        int colunas = scanner.nextInt();

        // Matriz entao
        int [][] matriz = new int [linhas][colunas];
		
		
		for (int i = 0; i<linhas; i++){
			for(int j =0; j<colunas; j++){
				System.out.println("Insira o valor para formar a matriz:");
                 matriz [i][j]= scanner.nextInt();
				
			}
		}
		
		System.out.println("A nossa matriz e: ");
		
		for (int i = 0; i<linhas; i++){
			for(int j =0; j<colunas; j++){
				System.out.print(matriz [i][j]+" ");
             	
			}
			
			System.out.println();
		}
		
		for (int i = 0; i<linhas; i++){
			for(int j =0; j<colunas; j++){
				if (matriz [i][j] % 2 ==0){
				matriz [i][j] = 1;	
				}else {
				matriz [i][j] = -1;	
				}
			}
		}
		
		System.out.println("A nossa matriz modificada e: ");
		for (int i = 0; i<linhas; i++){
			for(int j =0; j<colunas; j++){
				
				System.out.print(matriz [i][j]+" ");
			}
			
			System.out.println();
		}
		
		
		
		
	}
}