
import java.util.ArrayList;

public class ArrayListCloneExample {
    public static void main(String[] args) {
        // Criar um ArrayList e adicionar elementos
        ArrayList<String> originalList = new ArrayList<>();
        originalList.add("A");
        originalList.add("B");
        originalList.add("C");

        // Clonar o ArrayList
        ArrayList<String> clonedList = (ArrayList<String>) originalList.clone();

        // Exibir as listas
        System.out.println("Lista Original: " + originalList);
        System.out.println("Lista Clonada: " + clonedList);
    }
}