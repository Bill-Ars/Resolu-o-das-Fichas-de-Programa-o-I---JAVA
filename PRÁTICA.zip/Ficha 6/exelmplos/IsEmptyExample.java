public class IsEmptyExample {
    public static void main(String[] args) {
        String str1 = "";
        String str2 = "Hello, World!";

        // Verificando se as strings estão vazias
        System.out.println("str1 está vazia? " + str1.isEmpty()); // Saída: true
        System.out.println("str2 está vazia? " + str2.isEmpty()); // Saída: false
    }
}