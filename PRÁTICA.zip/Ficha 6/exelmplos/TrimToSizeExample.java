import java.util.ArrayList;

public class TrimToSizeExample {
    public static void main(String[] args) {
        // Criar um ArrayList com capacidade inicial
        ArrayList<String> languages = new ArrayList<>(10);
        
        // Adicionar elementos ao ArrayList
        languages.add("Java");
        languages.add("Python");
        languages.add("JavaScript");

        // Exibir a capacidade e o tamanho antes de trimToSize
        System.out.println("Capacidade antes: " + languages.size());

        // Reduzir a capacidade para corresponder ao tamanho atual
        languages.trimToSize();

        // Exibir a capacidade e o tamanho após trimToSize
        System.out.println("Capacidade após: " + languages.size());
    }
}