/*Programa que recebe um array e ordena em ordem crescente*/


import java.util.Scanner;

public class OrdemCrescenteUnidimensional15{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Tamanho do array: ");
        int quant = scanner.nextInt();
        
        int[] V = new int[quant];
        
        // Leitura dos valores do array
        for (int i = 0; i < V.length; i++) {
            System.out.println("Valor, por favor: ");
            V[i] = scanner.nextInt();
        }
		
		int temp = 0;
		
		for(int i = 0; i<V.length; i++){
			for(int j = i+1; j<V.length; j++){
				if(V[i]>V[j]){
					temp = V[i];
					V[i] = V[j];
					V[j] = temp;
				}
				
			}
		}
		
		for(int i = 0; i<V.length; i++){
		System.out.println(V[i]);
		}
		
		
		
		
	}
}
        