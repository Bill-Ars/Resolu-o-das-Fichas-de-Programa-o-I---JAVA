
 /* Escreva um método que recebe um array de números e devolve a posição onde se encontra 
o maior valor do array. Se houver mais de um valor maior, devolver a posição da primeira 
ocorrência. */

import java.util.Scanner;

public class Numero5Unidimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita o tamanho do vetor
        System.out.println("Insira o tamanho do vetor: ");
        int tamanho = scanner.nextInt();

        // Cria um array com o tamanho especificado
        double[] V = new double[tamanho];

        // Lendo os elementos do vetor
        for (int i = 0; i < V.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            V[i] = scanner.nextDouble();
        }

        // Inicializa o maior valor e a posição
        double maior = V[0];
        

        // Encontrando a posição do maior valor
        for (int i = 1; i < V.length; i++) {
            if (V[i] > maior) {
                maior = V[i];
               
            }
        }

        // Exibindo a posição do maior valor
        System.out.println("O maior valor é " + maior + " e está na posição: " +i); // +1 para exibir posição 1-indexed

        // Fechar o scanner
        scanner.close();
    }
}