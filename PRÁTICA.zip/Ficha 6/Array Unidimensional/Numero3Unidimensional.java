	/*    Faça um programa que para um vetor de 10 elementos positivos e em seguida encontre a 
		  posição no vetor de um elemento informado pelo usuário, caso o elemento não exista no 
	      vetor, informe o usuário. */

import java.util.Scanner;

public class Numero3Unidimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] V = new int[10];

        System.out.println("Digite 10 números positivos, a sua escolha:");
        for (int i = 0; i < V.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            int numero = scanner.nextInt();
		}
        // Solicitar o número a ser buscado
        System.out.print("\nDigite o número a ser buscado: ");
        int elementoBuscado = scanner.nextInt();

        // Procurar o elemento no vetor
        boolean encontrado = false;
        for (int i = 0; i < V.length; i++) {
            if (V[i] == elementoBuscado) {
                System.out.println("O número " + elementoBuscado + " está na posição " + (i + 1) + " do vetor.");
                encontrado = true;
                break; // Sair do loop se o número for encontrado
            }
        }

        // Informar se o número não foi encontrado
        if (!encontrado) {
            System.out.println("O número " + elementoBuscado + " não foi encontrado no vetor.");
        }

        scanner.close(); // Fechar o scanner
    }
}