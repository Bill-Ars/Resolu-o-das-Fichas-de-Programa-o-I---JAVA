/*8. Crie um programa que permite de determinar a soma dos valores de duas matrizes.*/

import java.util.Scanner;

public class SomaMatrizes8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite o número de linhas das matrizes: ");
        int linhas = scanner.nextInt();
        
        System.out.println("Digite o número de colunas das matrizes: ");
        int colunas = scanner.nextInt();
        
        // Declaração das matrizes
        int[][] matrizA = new int[linhas][colunas];
        int[][] matrizB = new int[linhas][colunas];
        int[][] matrizSoma = new int[linhas][colunas];
        
        // Leitura da primeira matriz
        System.out.println("Digite os elementos da primeira matriz (A):");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matrizA[i][j] = scanner.nextInt();
            }
        }
        
        // Leitura da segunda matriz
        System.out.println("Digite os elementos da segunda matriz (B):");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matrizB[i][j] = scanner.nextInt();
            }
        }
        
        // Cálculo da soma das matrizes
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                matrizSoma[i][j] = matrizA[i][j] + matrizB[i][j];
            }
        }
        
        // Impressão da matriz soma
        System.out.println("Matriz soma (A + B):");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print(matrizSoma[i][j] + " ");
            }
            System.out.println(); // Nova linha após cada linha da matriz
        }
        
        scanner.close(); // Fecha o scanner para evitar vazamento de recursos
    }
}