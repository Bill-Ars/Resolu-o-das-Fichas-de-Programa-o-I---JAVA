 /*Escreva um método que recebe um array de inteiros a e devolve um array de boolean onde, 
cada posição indique true se o elemento da posição correspondente de a é positivo e false 
caso seja negativo ou zero*/

import java.util.Scanner;

public class Numero6Unidimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita o tamanho do vetor
        System.out.println("Insira o tamanho do vetor: ");
        int tamanho = scanner.nextInt();

        // Cria um array com o tamanho especificado
        int[] a = new int[tamanho];

        // Lendo os elementos do vetor
        for (int i = 0; i < a.length; i++) {
            System.out.print("Número inteiro " + (i + 1) + ": ");
            a[i] = scanner.nextInt();
        }

        // Cria um array booleano para armazenar os resultados
        boolean[] resultado = new boolean[tamanho];

        // Verifica se cada elemento é positivo
        for (int i = 0; i < a.length; i++) {
            if (a[i] > 0) {
                resultado[i] = true; // O número é positivo
            } else {
                resultado[i] = false; // O número é negativo ou zero
            }
        }

        // Exibindo os resultados
        for (int i = 0; i < resultado.length; i++) {
            System.out.println("Posição " + (i + 1) + ": " + resultado[i]);
        }

        // Fechar o scanner
        scanner.close();
    }
}
