/* Faça um programa em Java que leia um vetor de 10 elementos numéricos inteiros, calcule e
mostre: 
• A quantidade de números pares 
• Quais os números pares
• A quantidade de números ímpares 
• Quais os números ímpares
 */
 
 import java.util.Scanner;
 
public class Numero1Elementos{
	 public static void main (String args[]){
		 
		 Scanner scanner = new Scanner(System.in);
		 
		 int V [] = new int [10];
		 
		 System.out.println("Digite 10 numeros inteiros:");
		 
		 for (int i = 0; i<V.length; i++){
			 System.out.println("numero "+(i+1)+" :");
			 V[i] = scanner.nextInt();
			 
		 }
		 
		
		
		int pares = 0;
		int impares = 0;
		
		for(int i = 0; i<V.length; i++){
			if(	V[i]%2 == 0){
				pares ++;
				System.out.println("O numero "+V[i]+" e par");
				}else{ 
			    impares ++;
				System.out.println("O numero "+V[i]+" e impar");
				
				
				
			}
		}
		  System.out.println("Sao "+pares+" numeros pares");
		  System.out.println("Sao "+impares+" numeros impares");
	 }
}