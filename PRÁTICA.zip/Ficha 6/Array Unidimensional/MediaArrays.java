import java.util.Scanner;

public class MediaArrays{
 public static void main(String[]args){
	 Scanner scanner = new Scanner(System.in);
	 
	 System.out.println("tamanho de notas: ");
	 int tamanho = scanner.nextInt();
		
		int V[] = new int [tamanho];
		
		for (int i = 0; i < V.length; i++){
			System.out.println("Nota" +(i+1)+ " : ");
			V[i] = scanner.nextInt();
		}
		
		int Soma = 0;
		int contador = 0;
		
		for (int i = 0; i < V.length; i++){
		
		Soma += V[i];
		contador ++;
		}
		
		double Media = (double) Soma/contador;
		
		System.out.println("Media: "+Media);
	}
 }