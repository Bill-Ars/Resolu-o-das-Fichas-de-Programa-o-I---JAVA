/* Crie um método que recebe um array de inteiros positivos e substitui seus elementos de 
valor ímpar por -1 e os pares por +1. */

import java.util.Scanner;

public class Numero4Unidimensional {
    public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in);
		
		
		System.out.println("Informe o tamanho do array:");
		int quant = scanner.nextInt();
		
        int[] V = new int[quant];
		
		System.out.println("Digite o numero:");
        for (int i = 0; i < V.length; i++) {
			
            System.out.print("Número " + (i + 1) + ": ");
            int numero = scanner.nextInt();
		

			
            if (numero <= 0) {
                System.out.print("O número deve ser positivo. Digite novamente: ");
                numero = scanner.nextInt();
            }
            V[i] = numero;
        }
		
		for (int i = 0; i < V.length; i++) {
			if(V[i]%2 == 0){
				
				V[i] = 1;
				
			} else {
				
				V[i] = -1;
			}
			
			
		}
		
		System.out.println("Vetor modificado:");
        for (int i = 0; i < V.length; i++) {
            System.out.println(V[i]);
        }
		
		
		
		
	}
}