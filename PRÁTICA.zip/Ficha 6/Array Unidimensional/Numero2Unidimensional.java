	
	/*Faça um programa em Java que leia um vetor com dez números reais, calcule e mostre a qu
	antidade de números negativos e a soma dos números positivos desse vetor.*/

 import java.util.Scanner;
 
public class Numero2Unidimensional{
	 public static void main (String args[]){
		 
		 Scanner scanner = new Scanner(System.in);
		 
		 double [] V = new double [10];
		 
	
		 System.out.println("Digite 10 números reais:");
		 for (int i = 0;i<V.length; i++){
			 
			 System.out.println("Insira o numero"+(i+1)+" real :");
			 V[i] = scanner.nextDouble();
		 }
		 
		
		int negativos = 0;
		int Somaposit = 0;
		
		for (int i = 0; i <V.length; i++){
		
		 if (V[i]<0){
		 negativos ++;
		
		 }else{
		 Somaposit += V[i];
		 }
		}
		
		System.out.println("Sao "+negativos+" negativos.");
		System.out.println("A soma dos positivos: "+Somaposit);	
	}
}
		

