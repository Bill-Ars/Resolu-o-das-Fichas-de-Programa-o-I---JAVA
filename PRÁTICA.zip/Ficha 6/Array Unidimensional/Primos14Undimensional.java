/*Programa que a partir de um array inmfromo se um numero e primo*/


import java.util.Scanner;

public class Primos14Undimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Tamanho do array: ");
        int quant = scanner.nextInt();
        
        int[] V = new int[quant];
        
        // Leitura dos valores do array
        for (int i = 0; i < V.length; i++) {p
            System.out.println("Valor, por favor: ");
            V[i] = scanner.nextInt();
        }
        
        // Verificação de números primos
        for (int i = 0; i < V.length; i++) {
            int numero = V[i];
            boolean isPrimo = true;

            if (numero <= 1) {
                isPrimo = false;
            } else {
                for (int j = 2; j <= Math.sqrt(numero); j++) {
                    if (numero % j == 0) {
                        isPrimo = false;
                        break; // Se encontrar um divisor, não precisa continuar
                    }
                }
            }

            if (isPrimo) {
                System.out.println("O número " + numero + " é primo.");
            } else {
                System.out.println("O número " + numero + " não é primo.");
            }
        }

        scanner.close(); // Fecha o scanner para evitar vazamento de recursos
    }
}