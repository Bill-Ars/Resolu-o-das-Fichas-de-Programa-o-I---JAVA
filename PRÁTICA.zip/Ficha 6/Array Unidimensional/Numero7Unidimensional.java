
  /*Crie um método que recebe um array de inteiros a e um valor inteiro x e retorna a 
quantidade de vezes que x aparece no array a*/
import java.util.Scanner;

  public class Numero7Unidimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Insira o tamanho do vetor: ");
        int tamanho = scanner.nextInt();

        // Cria um array com o tamanho especificado
        int [] a = new int [tamanho];

        // Lendo os elementos do vetor
        for (int i = 0; i < a.length; i++) {
            System.out.print("Número inteiro " + (i + 1) + ": ");
            a[i] = scanner.nextInt();
        }
		
		System.out.println("Insira um valor inteiro: ");
        int x = scanner.nextInt();
		
		int contador = 0;
		
		for (int i = 0; i < a.length; i++){
			if(a[i] == x){
			contador ++;
			}
		}
		
		System.out.println("O valor aparece "+contador+" vezes no vector");
		
		
	}
  }