  /* Faça um programa em Java que receba o nome de cinco produtos e seus respectivos preço,
armazene em dois vetores separados, um para os produtos e outro para os preços. O progra
ma deve calcular e mostrar: 
a) A quantidade de produtos com preço inferior a 500,00;
b) O nome dos produtos com preço entre 500,00 e 1000,00; 
c) A média dos preços dos produtos com preço superior a 1000,00. */

 import java.util.Scanner;

  public class Numero9Unidimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		String V [] = new String [5];
		
		for (int i = 0; i<V.length; i++ ){
			 System.out.println("Produto "+(i+1)" :");
            String V[i]=scanner.nextLine();
		}
		
		double B [] = new double [5];
		
		for (int i = 0; i<B.length; i++ ){
			 System.out.print("Preco "+(i+1)" :");
             B[i]= scanner.nextDouble();
		}
		
		//a) A quantidade de produtos com preço inferior a 500,00;
		//b) O nome dos produtos com preço entre 500,00 e 1000,00;
		//c) A média dos preços dos produtos com preço superior a 1000,00. */
		
		int contador = 0;
		int Soma = 0;
		int Somapd = 0;
		
		for (int i = 0; i<B.length; i++ ){
			if(B[i]<500){
				Soma ++;
				
			}
		}else if (B[i]>500 && B[i]<1000){
				System.out.println("O produto"+V[i]+"tem preco entre 500 e 100 Mt");
			}
		}else{
			contador ++;
			Somapd++;
		}
		
		double Mediapd = Soma/contador;
		
		System.out.println("Sao "+Soma+"Produtos com preco inferior a 500,00 Mt");
		System.out.println("Media dos produtos com mais de 100,00 mt: "+Media);
		
	}
}
