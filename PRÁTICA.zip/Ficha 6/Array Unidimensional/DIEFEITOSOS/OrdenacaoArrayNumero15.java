/* Crie um método que recebe um array e coloque os elementos do array em ordem 
crescente. Não use o método sort.*/

import java.util.Scanner;

public class OrdenacaoArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criação do array para armazenar os números
        int tamanho = 5; // Definindo o tamanho do array
        int[] numeros = new int[tamanho];

        // Receber os números do usuário
        System.out.println("Digite " + tamanho + " números:");
        for (int i = 0; i < tamanho; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        // Ordenação do array em ordem crescente usando Bubble Sort
        for (int i = 0; i < numeros.length - 1; i++) {
            for (int j = 0; j < numeros.length - 1 - i; j++) {
                if (numeros[j] > numeros[j + 1]) { // Se o elemento atual for maior que o próximo
                    // Troca os elementos
                    int temp = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = temp;
                }
            }
        }

        // Exibir o array ordenado
        System.out.println("Array ordenado em ordem crescente:");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        
        scanner.close(); // Fecha o scanner
    }
}