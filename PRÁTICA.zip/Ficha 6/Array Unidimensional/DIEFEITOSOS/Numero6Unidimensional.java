 /*Escreva um método que recebe um array de inteiros a e devolve um array de boolean onde, 
cada posição indique true se o elemento da posição correspondente de a é positivo e false 
caso seja negativo ou zero*/

 public class Numero6Unidimensional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita o tamanho do vetor
        System.out.println("Insira o tamanho do vetor: ");
        int tamanho = scanner.nextInt();

        // Cria um array com o tamanho especificado
        int [] V = new int [tamanho];

        // Lendo os elementos do vetor
        for (int i = 0; i < V.length; i++) {
            System.out.print("Número inteiro " + (i + 1) + ": ");
            V[i] = scanner.nextInt();
        }
		
		String resultado;
		
		for (int i = 0; i < V.length; i++){
			
			if (V[i])>0){
				resultado = True;
			}else{
			resultado = False;	
			}
		}
		
		for (int i = 0; i < V.length; i++){
			System.out.println ("Posicao" +(i+1)+":"+resultado);
		}
		
		
		
		
	}
 }
