/* Faça um programa em Java que receba o nome de cinco produtos e seus respectivos preço,
armazene em dois vetores separados, um para os produtos e outro para os preços. O progra
ma deve calcular e mostrar: 
a) A quantidade de produtos com preço inferior a 500,00;
b) O nome dos produtos com preço entre 500,00 e 1000,00; 
c) A média dos preços dos produtos com preço superior a 1000,00. */



import java.util.Scanner;

public class Numero9UnidimensionalCERTO {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] produtos = new String[5]; // Array para armazenar os nomes dos produtos
        double[] precos = new double[5]; // Array para armazenar os preços dos produtos

        // Recebe os nomes dos produtos
        for (int i = 0; i < produtos.length; i++) {
            System.out.print("Produto " + (i + 1) + ": ");
            produtos[i] = scanner.nextLine();
        }

        // Recebe os preços dos produtos
        for (int i = 0; i < precos.length; i++) {
            System.out.print("Preço do " + produtos[i] + ": ");
            precos[i] = scanner.nextDouble();
        }

        // a) A quantidade de produtos com preço inferior a 500,00
        int quantidadeInferior500 = 0;

        // b) O nome dos produtos com preço entre 500,00 e 1000,00
        System.out.println("Produtos com preço entre 500,00 e 1000,00:");
        
        // c) A média dos preços dos produtos com preço superior a 1000,00
        double somaPrecosSuperiores1000 = 0;
        int contadorSuperiores1000 = 0;

        for (int i = 0; i < precos.length; i++) {
            if (precos[i] < 500) {
                quantidadeInferior500++;
            } else if (precos[i] >= 500 && precos[i] <= 1000) {
                System.out.println(produtos[i]);
            } else { // Preços superiores a 1000
                somaPrecosSuperiores1000 += precos[i];
                contadorSuperiores1000++;
            }
        }

        // Cálculo da média dos preços superiores a 1000,00
        double mediaPrecosSuperiores1000 = contadorSuperiores1000 > 0 ? somaPrecosSuperiores1000 / contadorSuperiores1000 : 0;

        // Resultados
        System.out.println("Quantidade de produtos com preço inferior a 500,00: " + quantidadeInferior500);
        System.out.printf("Média dos preços dos produtos com preço superior a 1000,00: %.2f\n", mediaPrecosSuperiores1000);

        scanner.close(); // Fecha o scanner
    }
}