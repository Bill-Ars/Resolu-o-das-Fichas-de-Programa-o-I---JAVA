/* 10. Faça um programa em Java que receba o total das vendas de cada vendedor e armazene-as em um vetor.
 Receba também o percentual de comissão de cada vendedor e armazene-os em outro vetor. 
 Receba os nomes desses vendedores e armazene-os 
em um terceiro vetor. Existem apenas dez vendedores. Calcule e mostre: 
a) Um relatório com os nomes dos vendedores e os valores a receber; 
b) O total das vendas de todos os vendedores; 
c) O maior valor a receber e quem o receberá; 
d) O menor valor a receber e quem o receberá. */

import java.util.Scanner;

public class Numero10{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double TotVendas[] = new double[10];
        double Comis[] = new double[10];
        String Nome[] = new String[10];

        // Coleta de dados
        for (int i = 0; i < TotVendas.length; i++) {
            System.out.print("Total das vendas do vendedor " + (i + 1) + ": ");
            TotVendas[i] = scanner.nextDouble();
            scanner.nextLine(); // Limpa o buffer para evitar problemas ao ler o nome
            System.out.print("Nome do vendedor " + (i + 1) + ": ");
            Nome[i] = scanner.nextLine();
            System.out.print("Comissão do vendedor " + (i + 1) + ": ");
            Comis[i] = scanner.nextDouble();
        }

        double ValorRec[] = new double[10];

        // Cálculo dos valores a receber
        for (int i = 0; i < ValorRec.length; i++) {
            ValorRec[i] = TotVendas[i] * (1 + Comis[i]); // Calcula o valor a receber
            System.out.println("O vendedor " + Nome[i] + " recebe: " + ValorRec[i]);
        }

        // Cálculo do total das vendas
        double totalVendas = 0;
        for (int i=0; i<TotVendas.length; i++){
			totalVendas += TotVendas [i];
			
		}
        
        System.out.println("Total das vendas de todos os vendedores: " + totalVendas);

        // Cálculo do maior valor a receber
        double maiorValor = ValorRec[0];
        String receptorMaior = Nome[0];
        for (int i = 1; i < ValorRec.length; i++) {
            if (ValorRec[i] > maiorValor) {
                maiorValor = ValorRec[i];
                receptorMaior = Nome[i];
            }
        }
        System.out.println("O maior valor a receber é: " + maiorValor + ", e será recebido por: " + receptorMaior);

        // Cálculo do menor valor a receber
        double menorValor = ValorRec[0];
        String receptorMenor = Nome[0];
        for (int i = 1; i < ValorRec.length; i++) {
            if (ValorRec[i] < menorValor) {
                menorValor = ValorRec[i];
                receptorMenor = Nome[i];
            }
        }
        System.out.println("O menor valor a receber é: " + menorValor + ", e será recebido por: " + receptorMenor);
        
        scanner.close(); // Fecha o scanner para evitar vazamento de recursos
    }
}