/*Escreva um programa para ler uma quantidade indeterminada de palavras (o programa 
termina ao ser informado uma palavra que começa com a letra ‘f’). Para cada palavra 
informada (incluindo a última) escrever a primeira e a última letra.*/

import java.util.Scanner;

public class LETRAPalavra {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        do {
            System.out.println("Insira a palavra: ");
            String palav = scanner.nextLine();
            
            // Verifica se a palavra não está vazia antes de acessar os caracteres
            if (!palav.isEmpty()) {
                System.out.println("Para a palavra " + palav);
                
                // Exibe a primeira e a última letra
                System.out.println("A primeira letra: " + palav.charAt(0));
                System.out.println("A última letra: " + palav.charAt(palav.length() - 1));
            }
            
        }while (palav.charAt(0) != 'f' && palav.charAt(0) != 'F'); // Correção na condição
        
        System.out.println("Fim do programa! (Digitou a palavra com início em f!)");
        
        scanner.close(); // Fecha o scanner
    }
}