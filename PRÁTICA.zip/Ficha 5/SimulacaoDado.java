import java.util.Random;

public class SimulacaoDado {
    public static void main(String[] args) {
        // Cria um objeto Random para gerar números aleatórios
        Random random = new Random();

        // Simula as jogadas do dado dez vezes
        for (int i = 1; i <= 10; i++) {
            // Gera um número aleatório entre 1 e 6 (inclusive)
            int resultadoDado = random.nextInt(6) + 1;

            // Exibe o resultado da jogada atual
            System.out.println("Jogada " + i + ": " + resultadoDado);
        }
    }
}