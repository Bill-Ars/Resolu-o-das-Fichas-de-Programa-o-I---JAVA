public class Exer{
    public static void main(String[] args) {
        String a = "Milena";
		String b = "";
		
		for (int i = a.length(i)-1; i>=0; i--){
		b = b+acharAt(i);
		}
		System.out.println(b);
		}
}