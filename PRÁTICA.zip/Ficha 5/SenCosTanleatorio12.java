/*. Faça um programa que receba um número aleatório de zero até um numero digitado pelo 
usuário. O programa deverá exibir o seno, cosseno, tangente, raiz quadrada e potência do 
número gerando pelo método Math.random.
*/

import java.util.Scanner;
import java.util.Random;

public class SenCosTanleatorio12{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		Random random = new Random ();

        // Solicita ao usuário que insira um número máximo
        System.out.print("Digite um número máximo: ");
        int numeroMaximo = scanner.nextInt();

        // Gera um número aleatório entre 0 e numeroMaximo
        int numeroAleatorio = random.nextInt()* numeroMaximo;

        // Calcula seno, cosseno, tangente, raiz quadrada e potência
        double seno = Math.sin(numeroAleatorio);
        double cosseno = Math.cos(numeroAleatorio);
        double tangente = Math.tan(numeroAleatorio);
        double raizQuadrada = Math.sqrt(numeroAleatorio);
        double potencia = Math.pow(numeroAleatorio, 2); // Potência de 2

        // Exibe os resultados
        System.out.printf("Número aleatório gerado: %.2f%n", numeroAleatorio);
        System.out.printf("Seno: %.4f%n", seno);
        System.out.printf("Cosseno: %.4f%n", cosseno);
        System.out.printf("Tangente: %.4f%n", tangente);
        System.out.printf("Raiz Quadrada: %.4f%n", raizQuadrada);
        System.out.printf("Potência (ao quadrado): %.4f%n", potencia);

        // Fecha o scanner
        scanner.close();
    }
}