import  java.util.Scanner;

public class Programa{
	public static void main(String args[]){
		Scanner scanner = new Scanner (System.in);
		
		System.out.println("Insira a sua idade: ");
		int idade = scanner.nextInt();
		
		if(idade <10){
			System.out.println("Precisa de acompanhamento");
		}else{
			System.out.println("Sinta-se livre, caro!");
		}
	}
}	