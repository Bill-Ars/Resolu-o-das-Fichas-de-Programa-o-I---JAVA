/*5. Escreva um programa Java que:
a) Declara, constrói um ArrayList de inteiros e pede ao usuário para informar 10 valores de seus 
elementos.
b) Em seguida, pesquise no ArrayList e informe a existência ou não de valores repetidos.
Programação I


c) Ordenar os elementos do ArrayList de forma decrescente.
d) Modificar o 5° elemento da lista por um valor x introduzido pelo usuário do ArrayList.*/

import java.util.ArrayList;

import java.util.Scanner;

public class Numero5ArrayList{
	public static void main(String args[]){
		ArrayList<Integer> L = new ArrayList<Integer> ();
		Scanner ler = new Scanner(System.in);
		
		for (int i =0; i<10; i++){
			System.out.println("Insira o elemento da lista: ");
			int elem = ler.nextInt();
			L.add(elem);
		}
		
		// b) Verificar se existem valores repetidos
        HashSet<Integer> set = new HashSet<>(L);
        if (set.size() < L.size()) {
            System.out.println("Existem valores repetidos na lista.");
        } else {
            System.out.println("Não existem valores repetidos na lista.");
        }
		
		System.out.println("valor da lista: ");
		int valor = ler.nextInt();
		
		int contador = 0;
		    for (int i=0; i<L.size; i++){
				if(valor = L.get(i)){
					contador++;
					}
			}	
		
		if(int contador >= 2){
			System.out.println("O array contem valores repetidos");
		}else 
		     {
				 System.out.println("O array nao contem valores repetidos");
			 }
		
		for (int i = 0; i < L.size(); i++){
			if (L.get(i) < L.get(i+1)){
				int temp = L.get(i);
				L.set(i, L.get(i+1));
				L.set(i+1, temp);
				
			}
		}
		
		// Exibir a lista ordenada
        System.out.println("Lista ordenada em ordem decrescente: " + L);
		
		// d) Modificar o 5° elemento da lista por um valor x introduzido pelo usuário
        System.out.print("Insira um novo valor para o 5° elemento: ");
        int novoValor = ler.nextInt();

        // Verifica se há pelo menos 5 elementos
        if (L.size() >= 5) {
            L.set(4, novoValor); // O índice 4 corresponde ao 5° elemento
            System.out.println("Lista após modificar o 5° elemento: " + L);
        } else {
            System.out.println("A lista não contém 5 elementos.");
        }

        ler.close(); // Fecha o scanner
		
		
	}
}