
/*Faça um programa que leia um código numérico inteiro e uma lista de 15 posições de números 
reais. Se o código for zero, termine o programa. Se o código for 1, mostre a lista na ordem direta. 
Se o código for 2, mostre a lista na ordem inversa.
*/

	import java.util.ArrayList;
import java.util.Scanner;

public class ListaNumeros9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Double> lista = new ArrayList<>(15);

        // Ler 15 números reais
        System.out.println("Insira 15 números reais:");
        for (int i = 0; i < 15; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            double numero = scanner.nextDouble();
            lista.add(numero);
        }

        int codigo; // Declarar a variável do código fora do loop

        // Loop para ler o código e exibir a lista
        do {
            // Ler o código
            System.out.print("Insira um código (0 para sair, 1 para ordem direta, 2 para ordem inversa): ");
            codigo = scanner.nextInt();

            // Se o código for zero, termina o programa
            if (codigo == 0) {
                System.out.println("Programa encerrado.");
            }   
            // Se o código for 1, mostra a lista na ordem direta
            else if (codigo == 1) {
                System.out.println("Lista na ordem direta:");
                for (double num : lista) {
                    System.out.print(num + " ");
                }
                System.out.println(); // Nova linha
            }
            // Se o código for 2, mostra a lista na ordem inversa
            else if (codigo == 2) {
                System.out.println("Lista na ordem inversa:");
                for (int i = lista.size() - 1; i >= 0; i--) {
                    System.out.print(lista.get(i) + " ");
                }
                System.out.println(); // Nova linha
            } 
            else {
                System.out.println("Código inválido. Tente novamente.");
            }

        } while (codigo != 0); // Continua enquanto o código não for zero

        scanner.close(); // Fecha o scanner
    }
}