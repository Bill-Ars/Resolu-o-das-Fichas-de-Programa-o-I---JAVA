import java.util.ArrayList;
import java.util.Scanner;

public class OrdenacaoArrayListNumero4 {
    public static void main(String[] args) {
        // Criar uma ArrayList para armazenar inteiros
        ArrayList<Integer> numeros = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        // Solicitar ao usuário que insira 5 valores
        System.out.println("Informe 5 valores inteiros:");

        for (int i = 0; i < 5; i++) { // Garantir que 5 valores sejam lidos
            System.out.println("Valor " + (i + 1) + ": ");
            int valor = scanner.nextInt(); // Lê um inteiro do usuário
            numeros.add(valor); // Adiciona o valor à ArrayList
        }

        // Ordenar a ArrayList usando Bubble Sort
        for (int i = 0; i < numeros.size() - 1; i++) {
            for (int j = 0; j < numeros.size() - 1 - i; j++) { // Loop interno para Bubble Sort
                if (numeros.get(j) > numeros.get(j + 1)) {
                    // Trocar os elementos
                    int temp = numeros.get(j);
                    numeros.set(j, numeros.get(j + 1));
                    numeros.set(j + 1, temp);
                }
            }
        }

        // Imprimir os valores ordenados
        System.out.println("Valores ordenados de forma crescente:");
        for (int numero : numeros) { // Usando loop aprimorado para imprimir os números
            System.out.println(numero);
        }

        scanner.close(); // Fecha o scanner para evitar vazamentos de recursos
    }
}