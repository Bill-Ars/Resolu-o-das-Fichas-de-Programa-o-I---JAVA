/*. O Zodíaco chinês é composto por animais com ciclo de 12 anos. Uma maneira simplificada de 
identificá-lo é verificando-se apenas o ano de seu nascimento do seguinte modo:
Crie um programa com ArrayList que recebe o ano de nascimento do usuário e retorne o signo 
correspondente.*/

import java.util.ArrayList;
import java.util.Scanner;

public class ZodiacoChines {
    public static void main(String[] args) {
        // Criar uma ArrayList para armazenar os signos do zodíaco chinês
        ArrayList<String> signos = new ArrayList<>();
        signos.add("Rato");
        signos.add("Boi");
        signos.add("Tigre");
        signos.add("Coelho");
        signos.add("Dragão");
        signos.add("Serpente");
        signos.add("Cavalo");
        signos.add("Cabra");
        signos.add("Macaco");
        signos.add("Galo");
        signos.add("Cão");
        signos.add("Porco");

        Scanner scanner = new Scanner(System.in);

        // Solicitar ao usuário que insira seu ano de nascimento
        System.out.print("Informe seu ano de nascimento: ");
        int anoNascimento = scanner.nextInt();

        // Calcular o índice do signo no ciclo de 12 anos
        int indiceSigno = anoNascimento % 12;

        // Exibir o signo correspondente
        System.out.println("Seu signo do Zodíaco Chinês é: " + signos.get(indiceSigno));

        scanner.close(); // Fechar o scanner
    }
}