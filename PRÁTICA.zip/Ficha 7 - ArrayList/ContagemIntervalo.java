/*8. Construa um prograjma que leia dois números inteiros a e b, uma lista de tamanho N e exiba como 
resposta a contagem de qjauantos elementos da lista estão no intervalo fechado [a; b]
*/


import java.util.ArrayList;
import java.util.Scanner;

public class ContagemIntervalo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ler os limites do intervalo
        System.out.print("Insira o valor de a: ");
        int a = scanner.nextInt();
        System.out.print("Insira o valor de b: ");
        int b = scanner.nextInt();

        // Garantir que a seja menor ou igual a b
        if (a > b) {
            System.out.println("O valor de 'a' deve ser menor ou igual ao valor de 'b'.");
            return;
        }

        // Ler o tamanho da lista
        System.out.print("Insira o tamanho da lista (N): ");
        int N = scanner.nextInt();

        ArrayList<Integer> lista = new ArrayList<>();

        // Ler os elementos da lista
        System.out.println("Insira " + N + " números inteiros:");
        for (int i = 0; i < N; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            int numero = scanner.nextInt();
            lista.add(numero);
        }

        // Contar quantos elementos estão no intervalo [a; b]
        int contagem = 0;
        for (int numero : lista) {
            if (numero >= a && numero <= b) {
                contagem++;
            }
        }

        // Exibir o resultado
        System.out.println("Quantidade de elementos no intervalo [" + a + "; " + b + "]: " + contagem);

        scanner.close(); // Fecha o scanner
    }
}