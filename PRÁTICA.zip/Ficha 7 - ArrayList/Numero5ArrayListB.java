import java.util.ArrayList;
import java.util.Scanner;

public class Numero5ArrayListB {
    public static void main(String[] args) {
        ArrayList<Integer> L = new ArrayList<>();
        Scanner ler = new Scanner(System.in);

        // a) Solicitar ao usuário para inserir 10 valores
        for (int i = 0; i < 10; i++) {
            System.out.print("Insira o elemento da lista: ");
            int elem = ler.nextInt();
            L.add(elem);
        }

        // b) Verificar se existem valores repetidos
        boolean hasDuplicates = false;
        for (int i = 0; i < L.size(); i++) {
            for (int j = i + 1; j < L.size(); j++) {
                if (L.get(i).equals(L.get(j))) {
                    hasDuplicates = true;
                    break;
                }
            }
            if (hasDuplicates) {
                break;
            }
        }

        if (hasDuplicates) {
            System.out.println("Existem valores repetidos na lista.");
        } else {
            System.out.println("Não existem valores repetidos na lista.");
        }

        // c) Ordenar os elementos do ArrayList de forma decrescente sem usar sort()
        for (int i = 0; i < L.size(); i++) {
            for (int j = i + 1; j < L.size(); j++) {
                if (L.get(i) < L.get(j)) {
                    // Troca os elementos
                    int temp = L.get(i);
                    L.set(i, L.get(j));
                    L.set(j, temp);
                }
            }
        }

        // Exibir a lista ordenada
        System.out.println("Lista ordenada em ordem decrescente: " + L);

        // d) Modificar o 5° elemento da lista por um valor x introduzido pelo usuário
        System.out.print("Insira um novo valor para o 5° elemento: ");
        int novoValor = ler.nextInt();

        // Verifica se há pelo menos 5 elementos
        if (L.size() >= 5) {
            L.set(4, novoValor); // O índice 4 corresponde ao 5° elemento
            System.out.println("Lista após modificar o 5° elemento: " + L);
        } else {
            System.out.println("A lista não contém 5 elementos.");
        }

        ler.close(); // Fecha o scanner
    }
}