/*1. Crie uma ArrayList de inteiros onde o usuário irá informar 5 valores e em seguida imprima os valores 
de maneira individual.*/

import java.util.ArrayList;
import java.util.Scanner;

public class NumeroUm {
    public static void main(String[] args) {
        // Criação da ArrayList para armazenar inteiros
        ArrayList<Integer> numeros = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira 5 valores
        System.out.println("Informe 5 valores inteiros:");

        for (int i = 0; i < 5; i++) {
            System.out.print("Valor " + (i + 1) + ": ");
            int valor = scanner.nextInt(); // Lê um inteiro do usuário
            numeros.add(valor); // Adiciona o valor à ArrayList
        }

        // Imprime os valores de maneira individual
        System.out.println("Os valores informados são:");
        for (int i = 0; i < 5; i++) {
            System.out.println(numeros.get(i));
        }

        scanner.close(); // Fecha o scanner para evitar vazamentos de recursos
    }
}