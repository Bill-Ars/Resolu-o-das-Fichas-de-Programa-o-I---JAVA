import java.util.Scanner;
public class EqLinear{
	public static void main(String[]args){
		Scanner ler = new Scanner (System.in);
		System.out.print("a: ");
		float a = ler.nextFloat();
		System.out.print("b: ");
		float b = ler.nextFloat();
		float x = -b/a;
		System.out.println("x = " +x);
		
		
	}
}