
import java.util.Scanner;

public class Soma{
	public static void main (String []args){
		Scanner Ler = new Scanner (System.in);
		
		System.out.print("Primeiro valor: ");
		int val1 = Ler.nextInt();
		System.out.print("Segundo valor: ");
		int val2 = Ler.nextInt();
		
		int Soma = val1 + val2;
		
		System.out.println("Soma: "+ Soma);
		
		
		
		
		
	}
}