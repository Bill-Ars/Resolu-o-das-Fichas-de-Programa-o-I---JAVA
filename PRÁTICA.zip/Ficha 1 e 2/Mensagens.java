
public class Mensagens{
	public static void main (String []args) {
		System.out.println("SEJA BEM VINDO");
		System.out.println("Bill");
		System.out.println("150");
		
	}
}