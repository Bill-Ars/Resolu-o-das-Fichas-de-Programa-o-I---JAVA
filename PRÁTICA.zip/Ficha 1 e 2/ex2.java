
public class TiposPrimitivos {
	public static void main (String []args){
//inteiros

//variaveis do byte
byte idade = 50;
byte Temperatura = 100;

//Variaveis do tipo short
short SalEstudante = 15000;
short Premios = 30000;

// Variaveis do tipo inteiros
int SalMinimo = 20000000;
int SalMaximo = 50000000;

// Variaveis do tipo long
long Long1 = 1000000L;
long long2 = 20000000L;

//Reais

// Variaveis do tipo float

float float1 = 5.5f
float float2 = 10.4f

// Variaveis do tipo double
double double1 = 0.4444444444444;
double double2 = 3.444444444443;


System.out.println("Valores das variaveis: ");
System.out.println("INTEIROS ");
System.out.println ("byte: " +idade+ "," +Temperatura;
System.out.println ("short: " +SalEstudante+ "," +Premio);
System.out.println ("int: " +SalMinimo+ "," +SalMaximo);
System.out.println ("long: " +Long1+ "," +Long2)
ystem.out.println("REAIS");
ystem.out.println ("float: " +float1+ "," +float2);
ystem.out.println ("double: " +double1+ "," +double2);



}
}

