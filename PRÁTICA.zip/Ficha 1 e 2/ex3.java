public class ex3 {
    public static void main(String[] args) {
	//ficha 2
        int numero=10;
        
        System.out.println("Valor inicial: " + numero);

	numero =20;
   
        System.out.println("Valor 1: " + numero);

	numero=30;
	System.out.println("Valor 2: " + numero);

        numero=40;
        System.out.println("Valor final: " + numero);
       
    }
}
