
public class VariaveisAmbiente {
    public static void main(String[] args) {
        // Obtendo as variáveis de ambiente
        String path = System.getenv("PATH");
        String temp = System.getenv("TEMP");
        String username = System.getenv("USERNAME");

        // Exibindo os valores das variáveis
        System.out.println("Valor da variável PATH: " + path);
        System.out.println("Valor da variável TEMP: " + temp);
        System.out.println("Valor da variável USERNAME: " + username);
    }
}