//Escreva um programa que verifique se uma nota é péssima (nota=1), ruim (2), regular (3), boa (4), 
//ótima (5) ou nenhuma delas nota inválida

import java.util.Scanner;

public class Notas{
	public static void main(String[]args){
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira a sua nota (1 a 5): ");
		int nota = scanner.nextInt();
	
		
		switch (nota){
			case 1:
			System.out.print("Pessima");
					break;
			case 2: 
			
			System.out.print("Ruim");
					break;
			case 3: 
			
			System.out.print("Ruim");
					break;
			case 4: 
			System.out.print("Boa");
					break;
			case 5: 
			System.out.print("Optima");
					break;
					
			default: System.out.println("Nenhuma delas");
					break;
			
		}
		
		
	}
}