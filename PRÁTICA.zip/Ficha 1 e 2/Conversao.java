import java.util.Scanner;

public class Conversao{
public static void main(String []args){
Scanner Ler = new Scanner (System.in);

System.out.print("Quantidade em segundos: ");
double Segundos = Ler.nextInt();

double Horas = (double)Segundos/3600;
double Minutos  = (double)Segundos/60;
double Segundos = (double)Segundos%60;

System.out.println("Quantidade de horas: " +Horas);
System.out.println("Quantidade em Minutos: " +Minutos);
System.out.println("Quantidade em Segundos: " +Segundos);



}
}

