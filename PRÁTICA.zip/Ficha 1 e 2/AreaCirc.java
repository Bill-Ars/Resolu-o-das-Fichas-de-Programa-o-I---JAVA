
import java.util.Scanner;

public class AreaCirc{
	
	public static void main(String[]args){
		
		Scanner ler = new Scanner (System.in);
		//Descrição de um programa que determina a área de uma circunferencia de raio de 12 cm
		
		final double raio = 12;
		
		final double PI = 3.14;
		
		double AreaCirc = PI*raio*raio;
		
		System.out.println("A área da Circunferencia é " + AreaCirc );
		}
}