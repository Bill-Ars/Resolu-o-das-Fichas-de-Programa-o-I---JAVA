
import java.util.Scanner;

public class Operacoes{
	public static void main(String[]args){
		Scanner Ler = new Scanner (System.in);
		
		System.out.print("Insira o primeiro valor: ");
		int val1 = Ler.nextInt();
		
		System.out.print("Insira o segundo valor: ");
		int val2 = Ler.nextInt();
		
		int Soma = val1 + val2;
		int Subtracao = val1 - val2;
		int Multiplicacao = val1 * val2;
		int Divisao = val1/val2;
		
		System.out.println("As operações são as seguintes: ");
		System.out.println("Soma = " +Soma);
		System.out.println("Subtracao = " +Subtracao);
		System.out.println("Multiplicacao = " +Multiplicacao);
		System.out.println("Divisao = " +Divisao);
		
		
		
		
	}
}