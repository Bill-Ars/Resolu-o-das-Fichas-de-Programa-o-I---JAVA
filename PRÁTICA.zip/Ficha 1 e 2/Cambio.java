import java.util.Scanner;

public class Cambio{
	public static void main (String []args){
		Scanner Ler = new Scanner (System.in);
		
		System.out.print("Insira o valor em Dolar: ");
		
		double ValDolar = Ler.nextDouble();
		
		double ValConv = (double)ValDolar * 63.27; //Mt
		
		System.out.println ("O valor em Metical é: " +ValConv ++"Meticais");
		
	
	}
	
		
}