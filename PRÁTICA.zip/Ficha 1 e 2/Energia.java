//Exercicio 12
import java.util.Scanner;
public class Energia{
	public static void main (String []args){
		Scanner Ler = new Scanner (System.in);
		System.out.print("Insira o Salario Minimo: ");
		double SalMin = Ler.nextDouble();
		System.out.print("Insira a Quantidade de Quilowatts gasta: ");
		double Qgasta = Ler.nextDouble();
		
		double Valquil = 1/7*SalMin;
		double Preco = Valquil*Qgasta;
		double NovoPreco = Preco - Preco*0.10;
		
		
			System.out.println("O valor de cada quilowatt é: " +Valquil +"Meticais");
			System.out.println("O valor de a ser pago é: " +Preco +"Meticais");
			System.out.println("O valor com desconto é: " +NovoPreco +"Meticais");
	}
}
		
		
	
		
		