import java.util.Scanner;

public class Divisores{
    public static void main(String[] args) {
	Scanner Scanner = new Scanner(System.in);
	
       System.out.print("Insira um numero: ");
	   int num = Scanner.nextInt();
	   
        for (int i = 1; i <= num; i++) {
			if(num % i ==0){
			System.out.println(i); 	
			}
            
        }
    }
}