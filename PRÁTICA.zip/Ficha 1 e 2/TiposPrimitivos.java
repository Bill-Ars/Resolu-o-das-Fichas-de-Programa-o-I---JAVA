
public class TiposPrimitivos {
	public static void main (String []args){
//inteiros

//variaveis do byte
byte idade = 50;
byte Temperatura = 100;

//Variaveis do tipo short
short SalEst= 15000;
short Premios = 30000;

// Variaveis do tipo inteiros
int SalMinimo = 20000000;
int SalMaximo = 50000000;

// Variaveis do tipo long
long long1 = 10000000000;
long long2 = 20000000034;

//Reais

// Variaveis do tipo float

float float1 = 5.5f;
float float2 = 10.4f;

// Variaveis do tipo double
double double1 = 0.4444444444444;
double double2 = 3.444444444443;


System.out.println("Valores das variaveis:");
System.out.println("INTEIROS");

System.out.println("byte: " +idade);
System.out.println("byte: " +Temperatura);

System.out.println("short: " +SalEst);
System.out.println("short: " +Premios);

System.out.println("int: " +SalMinimo);
System.out.println("int: " +SalMaximo);

System.out.println("long: " +long1);
System.out.println("long: " +long2);

System.out.println("REAIS");

System.out.println("float: " +float1);
System.out.println("float: " +float2);

System.out.println("double: " +double1);
System.out.println("double: " +double2);







}
}

