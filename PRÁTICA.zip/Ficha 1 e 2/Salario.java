//Escreva um programa que determina um salário bruto e salário líquido
//de um funcionário sabendo que: O salário por hora é de 148 Mt;
//O número de horas trabalhadas num mes é de 168h
//O desconto do INSS é de 9.14%

import java.util.Scanner;

public class Salario{
	public static void main(String []args){
		Scanner Ler = new Scanner(System.in);
		
	final short Sahora = 148;
	final short TotHoras = 168;
	
	final double Salbruto = Sahora*TotHoras;
	System.out.println("O salario bruto é:" +Salbruto);
	
	final double Desc = Salbruto*9.14/100;
	
	final double SalLiq = Salbruto-Desc;
	
	System.out.println("O Salário líquido do funcionário é:" +SalLiq);
	
	
	}
}