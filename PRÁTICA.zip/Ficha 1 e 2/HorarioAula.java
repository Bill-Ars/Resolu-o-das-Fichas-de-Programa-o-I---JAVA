
public class HorarioAula{
	public static void main(String args []) {
		
		System.out.println("Horário da Sexta-feira");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		System.out.println("|Horas        | Segunda-feira | Terca-feira | Quarta-feira | Quinta-feira | Sexta-feira  |      Sabado         |");
		System.out.println("|07:20 a 09:20| Fisica II     | Tec Com     | Fisica       | Matematica   | Progranmacao | Metodos de Estudos  |");
		System.out.println("|09:20 a 11:20| Tec Com       | Programacao | Arq Tec Comp | Tec Com      | An Matematica|  Arq Tec Comp       |");
		System.out.println("|11:20 a 13:20| Matematica    |             |              |              |              |                     |");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
	
	}
}	
