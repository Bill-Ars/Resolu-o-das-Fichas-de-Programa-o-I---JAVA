import java.util.Scanner;

public class MaiorNumero{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira o primeiro valor: ");
		double val1 = scanner.nextDouble();
		System.out.print("Insira o segundo valor: ");
		double val2 = scanner.nextDouble();
		System.out.print("Insira o terceiro valor: ");
		double val3 = scanner.nextDouble();
		
		double maior; // definimos o tipo que vai armazenar os numeros
		
		
		if (val1>val2 && val1>val3){
			maior = val1;
		}else{ 
		    if (val2>val1 && val2>val3){
			maior = val2;
		} else{ 
		maior = val3;
		}
		
		
		}
		
		System.out.println("O maior entre os 3 números é: "+maior);
	}
}