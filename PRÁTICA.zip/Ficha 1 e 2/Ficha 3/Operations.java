//Crie um programa que permite de Crie uma variável com um 
//caractere contendo uma operação (‘+’, ‘-’, ‘*’ ou ‘/’) e outras duas 
//com números inteiros. Execute a operação indicada pelo caractere 
//com as duas variáveis inteiras

import java.util.Scanner;

public class Operations{
	public static void main (String []args){
	Scanner Ler = new Scanner (System.in);
	
	System.out.println("val1: ");
	int Val1 = Ler.nextInt();
	System.out.println("val2: ");
	int Val2 = Ler.nextInt();	
	
	System.out.println("Escolha a operacao (+, -, *, /.): ");
	char Escolha = Ler.next().charAt(0);
	
	
	int Resultado = Ler.nextInt();

	
	
	
	
	switch (Escolha){
			case '+': 
			
			Resultado = Val1 + Val2;
						break;
						
			case '-':
			Resultado = Val1 - Val2;
						break;
						
			case '*': 
			 Resultado = Val1*Val2;
						break;
						
			case '/':
			
		    Resultado = Val1/Val2;
						break;
			default: 
			System.out.println("Opção inválida: Escolha uma Operação entre +, -, *, e /");
	}
	System.out.println("O resultadoo e: "+Resultado);


 }
}			
						
			
	
		