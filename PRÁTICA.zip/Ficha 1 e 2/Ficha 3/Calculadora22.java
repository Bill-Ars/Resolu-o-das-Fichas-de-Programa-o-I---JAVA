import java.util.Scanner;
public class Calculadora22{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira os dois números inteiros
        System.out.print("Digite o primeiro número inteiro: ");
        double num1 = scanner.nextInt();

        System.out.print("Digite o segundo número inteiro: ");
        double num2 = scanner.nextInt();

        
        

       double Soma = num1 + num2;
            
       double Subtração = num1 - num2;
       
	   double Multiplicação = num1 * num2;
       
	   double Divisão = num1 / num2;
				
                
       System.out.println("Soma: " +Soma+","+"Subtração: "+Subtração+","+"Multiplicação: "+Multiplicação+","+"Divisão: "+Divisão);
    

        // Fecha o scanner
        scanner.close();
    }
}