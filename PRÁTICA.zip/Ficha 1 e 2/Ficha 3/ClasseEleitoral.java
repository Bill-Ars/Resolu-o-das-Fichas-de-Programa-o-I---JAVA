import java.util.Scanner;
public class ClasseEleitoral {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira a idade
        System.out.print("Digite a idade da pessoa: ");
        int idade = scanner.nextInt();

        // Verifica a classe eleitoral com base na idade
        if (idade < 16) {
            System.out.println("Não pode votar.");
        } else if (idade< 18 || idade > 65) {
            System.out.println("Voto facultativo.");
        } else if (idade >= 18 && idade <= 65) {
            System.out.println("Voto obrigatório.");
        } else {
            System.out.println("Idade inválida.");
        }

        // Fecha o scanner
        scanner.close();
    }
}