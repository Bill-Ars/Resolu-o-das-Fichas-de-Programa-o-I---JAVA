import java.util.Scanner;

public class Calculadora{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira a operação
        System.out.print("Digite a operação (+, -, *, /): ");
        char operacao = scanner.next().charAt(0);

        // Solicita ao usuário que insira os dois números inteiros
        System.out.print("Digite o primeiro número inteiro: ");
        int num1 = scanner.nextInt();

        System.out.print("Digite o segundo número inteiro: ");
        int num2 = scanner.nextInt();

        // Variável para armazenar o resultado
        int resultado = scanner.nextInt();
        

        // Executa a operação com base no caractere fornecido
        switch (operacao) {
            case '+':
                resultado = num1 + num2;
                break;
            case '-':
                resultado = num1 - num2;
                break;
            case '*':
                resultado = num1 * num2;
                break;
            case '/':                    
				resultado = num1 / num2;
				
                break;
                
            default:
                System.out.println("Operação inválida. Por favor, escolha entre +, -, * ou /.");
				break;
             
        }

       
       
            System.out.println("Resultado: " +resultado);
    

        // Fecha o scanner
        scanner.close();
    }
}