//Crie uma variável contendo a idade de uma pessoa e verifique sua classe eleitoral: (até 16 anos não 
//pode votar); (entre 16 e 18 anos ou mais que 65 é facultativo); (entre 18 e 65 anos é obrigatório).
import java.util.Scanner;

public class ClasseEleitoralA {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira a idade
        System.out.print("Digite a idade da pessoa: ");
        int idade = scanner.nextInt();

        // Verifica a classe eleitoral com base na idade
        if (idade < 16) {
            System.out.println("Não pode votar.");
        } else if ((idade >= 16 && idade < 18) || idade > 65) {
            System.out.println("Voto facultativo.");
        } else if (idade >= 18 && idade <= 65) {
            System.out.println("Voto obrigatório.");
        } else {
            System.out.println("Idade inválida.");
        }

        // Fecha o scanner
        scanner.close();
    }
}