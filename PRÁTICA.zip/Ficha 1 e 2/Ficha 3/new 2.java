//Um banco concederá um crédito especial aos seus clientes, variável com o saldo médio no último 
//ano. Faça um programa que, para o saldo médio de um cliente, calcule o valor do 
//crédito e mostre uma mensagem informando o saldo médio e o valor do crédito de acordo com as 
//condições abaixo:
//• Saldo médio Percentual de 0 a 2000 nenhum crédito, 
//• Saldo de 2001 a 4000 terá 20% do valor do saldo médio,
//• Saldo de 4001 a 6000 terá 30% do valor do saldo médio, e 
//• Saldo acima de 6001 40% do valor do saldo médio.

public class SalMed{
	public static void main(String[]args){
		Scanner Ler = new Scanner (System.in);
		System.out.print("Insira o saldo medio: ");
		double SalMed = scanner.nextDouble();
		
		if (SalMed>=0&&SalMed<=2000){
			double Cred = SalMed*0;
			System.out.println("O saldo medio e: "+SalMed+","+"Valor do credito: "+Cred);
			}else{
				if(SalMed>=2001&&SalMed<=4000){
					double Cred = SalMed+SalMed*0.20;
					System.out.println("O saldo medio e: "+SalMed+","+"Valor do credito: "+Cred);
				
				}else{
					if (SalMed>=4001&&SalMed<=6000){
						double Cred = SalMed+SalMed*0.30;
						System.out.println("O saldo medio e: "+SalMed+","+"Valor do credito: "+Cred);
						
					}else if {
					double Cred = SalMed+SalMed*0.40;
					System.out.println("O saldo medio e: "+SalMed+","+"Valor do credito: "+Cred);
					}
				}
			}
	}
}
		