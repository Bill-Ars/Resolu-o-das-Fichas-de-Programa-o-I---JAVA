import java.util.Scanner;

public class ClassificacaoNota {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira a nota
        System.out.print("Digite a nota (1 a 5): ");
        int nota = scanner.nextInt();

        // Verifica a classificação da nota
        switch (nota) {
            case 1:
                System.out.println("Classificação: Péssima");
                break;
            case 2:
                System.out.println("Classificação: Ruim");
                break;
            case 3:
                System.out.println("Classificação: Regular");
                break;
            case 4:
                System.out.println("Classificação: Boa");
                break;
            case 5:
                System.out.println("Classificação: Ótima");
                break;
            default:
                System.out.println("Nota inválida. Digite uma nota entre 1 e 5.");
                break;
        }

        // Fecha o scanner
        scanner.close();
    }
}