import java.util.Scanner;

public class ATM{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira o saldo: ");
		double saldo = scanner.nextDouble();
		
		
		System.out.println("Deseja efectuar que operação?: ");
		System.out.println("1: Consulta");
		System.out.println("2: Transferencia");
		System.out.println("3: Levantamento");
		System.out.println("4: Depósito");
		System.out.println("Opção: ");
		int opcao = scanner.nextInt();
		
		
		
		switch (opcao){
			case 1: System.out.print("Saldo: "+saldo); 
				break;
					
			case 2: System.out.print("Para transferir, insira o valor: ");
					double valor = scanner.nextDouble();
				if (valor <= saldo){
					saldo = saldo-valor;
				}else{
					System.out.print("Saldo insuficiente");
				}
				System.out.print("Saldo: "+saldo); 
				break;
				
			case 3: System.out.print("Para levantar, insira o valor: "); 
					valor = scanner.nextDouble();	
				if (valor<=saldo){
				saldo = saldo - valor;
				}else {
				System.out.print("Saldo insuficiente."); 	
				}
				System.out.print("Saldo: "+saldo);
				break;
				
			case 4: System.out.println("Para o deposito, insira o valor: "); 
					valor = scanner.nextDouble();	
			    saldo = saldo + valor;
				System.out.println("Saldo: "+saldo);
				
				break;
			
			default: System.out.println("Opção inválida"); 
			return;
		}
	}
}