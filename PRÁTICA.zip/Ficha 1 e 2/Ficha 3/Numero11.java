
import java.util.Scanner;

public class Numero11{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		System.out.print("Insira o nome do produto: ");
		String nomeProd = scanner.nextLine();
		System.out.print("Insira o Preco do Produto: ");
		double Prec = scanner.nextDouble();
		System.out.print("Insira a quantidade: ");
		int Quant = scanner.nextInt();
		double ValPag;
		double PrecT;
		
		if (Quant<=10){
			ValPag = Prec*Quant;
														
		}else{
			if(Quant>=11&&Quant<=20){
				PrecT = Prec*Quant;
				double Desc = PrecT*0.10;
				ValPag = Quant*Prec - Desc;
				}else if(Quant>=21&&Quant<=50){
					PrecT = Prec*Quant;
					double Desc = PrecT*0.20;
					ValPag = Quant*Prec - Desc;
				}else{
					PrecT = Prec*Quant;
					double Desc = PrecT*0.25;
					ValPag = Quant*Prec - Desc;
					}
		}
		
		System.out.println("Produto: "+nomeProd);
        System.out.println("O valor a pagar é: "+ValPag);			
		System.out.println("--------------------------");	
		        System.out.println("Thank you!");	
	}
}