	//Escreva um programa para ler 3 notas de um aluno e informar se o aluno está aprovado, reprovado 
	//ou se deverá realizar o exame final.
	//• O aluno será Aprovado a média de suas notas for > 14
	//• O aluno será Reprovado se a média de suas notas for < 10
	//• O aluno deverá realizar o exame se a média de suas notas for >= 10 e < 14
	
	import java.util.Scanner;
	
	public class Numero8{
		public static void main (String []args){
			Scanner scanner = new Scanner(System.in);
			
			System.out.print("Insira a sua primeira nota: ");
			double nota1 = scanner.nextInt();
			System.out.print("Insira a sua segunda nota: ");
			double nota2 = scanner.nextInt();
			System.out.print("Insira a sua terceira nota: ");
			double nota3 = scanner.nextInt();
			
			
			double Media = (nota1 + nota2 + nota3)/3;
			System.out.print("A sua media e: "+Media);
			
			if (Media>14){
				System.out.print("Aprovado com sucesso!");
				}else if (Media<10){
					System.out.print("Reprovado");
					}else{
					System.out.print("e deve realizar o exame");	
					}
			
		}
		
	}
	