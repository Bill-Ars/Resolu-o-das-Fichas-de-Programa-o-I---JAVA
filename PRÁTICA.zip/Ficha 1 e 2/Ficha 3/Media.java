//Exercicio da Estrutura de seleccao
import java.util.Scanner;
public class Media{
	public static void main(String []args){
		Scanner Ler =  new Scanner (System.in);
		System.out.print("T1: ");
		double T1 = Ler.nextDouble();
		System.out.print("T2: ");
		double T2 = Ler.nextDouble();
		System.out.print("Proj: ");
		double Proj = Ler.nextDouble();
		double Media = T1*0.3 + T2*0.3 + Proj*0.4;
		if (Media<10){
			System.out.println("Excluido");
		} else if (Media<=13){
				System.out.println("Admitido");
		}else{
			System.out.println("Dispensado");
		}
			
		
	
		
	}
}