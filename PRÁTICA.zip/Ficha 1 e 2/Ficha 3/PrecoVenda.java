import java.util.Scanner;

public class PrecoVenda{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
	System.out.print("Insira o preco do produto: ");
	double Preco = scanner.nextDouble();
	
	if (Preco<340){
		double PrecoVenda = Preco+Preco*0.45;
		System.out.print("Preco de venda: "+PrecoVenda);
		}else{
			if(Preco>=340&&Preco<680){
				double PrecoVenda = Preco+Preco*0.35;
				System.out.print("Preco de venda: "+PrecoVenda);
				}else{
					if(Preco>=680 &&Preco<1020){
					double PrecoVenda = Preco+Preco*0.25;
					System.out.print("Preco de venda: "+PrecoVenda);
					}else{
					double PrecoVenda = Preco+Preco*0.15;	
					System.out.print("Preco de venda: "+PrecoVenda);
					}
				
		}
	
}	}
}