//Crie três variáveis inteiras e um trecho de código que descubra a maior entre elas. Imprima as três 
//variáveis em ordem crescente

import java.util.Scanner;

public class OrdemCrescente{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira o primeiro valor: ");
		int val1 = scanner.nextInt();
		System.out.print("Insira o segundo valor: ");
		int val2 = scanner.nextInt();
		System.out.print("Insira o terceiro valor: ");
		int val3 = scanner.nextInt();
		
		int menor, meio, maior; // definimos o tipo que vai armazenar os numeros
		
		
		if (val1>val2 && val1>val3){
			maior = val1;
			if (val2 > val3){
				meio = val2; 
				menor = val3;
			}else{ meio = val3;
				   menor = val2;
				
			}
		} else if (val2>val1 && val2>val3){
			maior = val2;
			if (val1>val3){
				meio = val1;
				menor = val3;
			}else{ meio = val3;
				   menor = val1;
				
			}
		} else{ 
		
			maior = val3;
			if (val1>val2){
				meio = val1;
				menor = val2;
			}else{
				meio = val2;
				menor = val1;
			}
		
		
		}
		
		System.out.println("Os números em ordem crscente são: " +menor+ "," +meio+ "," +maior);
	}
}