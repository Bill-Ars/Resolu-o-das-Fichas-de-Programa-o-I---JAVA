//Crie três variáveis inteiras e um trecho de código que descubra a maior entre elas. Imprima as três 
//variáveis em ordem crescente

import java.util.Scanner;

public class MaiorNota{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira a primeira nota: ");
		int nota1 = scanner.nextInt();
		System.out.print("Insira a segunda nota: ");
		int nota2 = scanner.nextInt();
		System.out.print("Insira a terceira nota: ");
		int nota3 = scanner.nextInt();
		
		int maior; // definimos o tipo que vai armazenar os numeros
		
		
		if (nota1>nota2 && nota1>nota3){
			maior = nota1;
			System.out.print("A maior nota é: "+nota1);
			System.out.print("A maior é a primeira");
		} else if (nota2>nota1 && nota2>nota3){
			maior = nota2;
			System.out.println("A maior nota é: "+nota2);
			System.out.println("A maior é a segunda");
		} else{ 
		maior = nota3;
		System.out.print("A maior nota é: "+nota3);
		System.out.print("A maior é a terceira");
		}
		
	}	
}