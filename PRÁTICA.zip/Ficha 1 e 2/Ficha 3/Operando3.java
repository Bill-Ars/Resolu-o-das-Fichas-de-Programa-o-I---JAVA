//Crie um programa que permite de Crie uma variável com um 
//caractere contendo uma operação (‘+’, ‘-’, ‘*’ ou ‘/’) e outras duas 
//com números inteiros. Execute a operação indicada pelo caractere 
//com as duas variáveis inteiras

import java.util.Scanner;

public class Operations{
	public static void main (String []args){
	Scanner Ler = new Scanner (System.in);
		
	System.out.println("Escolha a operacao (+, -, *, /.): ");
	Char Operacao = Ler.next().chatAt(0);
	
	System.out.println("val1: ");
	double Val1 = Ler.nextDouble();
	System.out.println("val2: ");
	double Val2 = Ler.nextDouble();
	
	
	switch ("Operacao"){
			case '+' : double Soma = Val1 + Val2;
			System.out.println("Resultado: "+Soma);
						break;
			case '-'= double Subtracao = Val1 - Val2;
			System.out.println("Resultado: "+Subtracao);
						break;
			case '*'= double Multiplicacao = Val1*Val2;
			System.out.println("Resultado: "+Multiplicacao);
						break;
			case '/' = double Divisao = Val1/Val2;
			System.out.println("Resultado: "+Divisao);
						break;
		default: ("Opção inválida: Escolha uma Operação entre +, -, *, e /");
	}
	

	

 }
}