
//Exercicio 10
import java.util.Scanner;
public class Combustivel{
	public static void main (String []args){
		Scanner Ler = new Scanner (System.in);
		
		double Tempo = 4; //horas
		double Velocidade = 80; // km/horas
		
		double distancia = Tempo*Velocidade;
		double LitrosUs = distancia/12;
		
		System.out.println("A quantidade de litros de Comustivel é: " +Tempo)
	}
		
}