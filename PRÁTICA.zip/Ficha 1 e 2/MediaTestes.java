import java.util.Scanner;

public class MediaTestes{
	
	public static void main(String[]args){
		// Média de tres testes
		
		Scanner ler = new Scanner (System.in);
		
		System.out.print("Insira a primeira nota: ");
		float Teste1 = ler.nextFloat();
		
		System.out.print("Insira a segunda nota: ");
		float Teste2 = ler.nextFloat();
		
		System.out.print("Insira a terceira nota: ");
		float Teste3 = ler.nextFloat();
		
		float Media = (Teste1+Teste2+Teste3)/3;
		
		System.out.println(" A Média é "+Media);
		
		}
}