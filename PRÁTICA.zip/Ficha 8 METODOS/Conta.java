/*13. Escreva um programa com um método com o nome conta_menores que recebe um array 
unidimensional contendo números inteiros e um número inteiro e que devolve o número de 
elementos do array Unidimensional que são menores do que esse inteiro.*/
import java.util.Scanner;
import java.util.Arrays;

public class Conta{
	
	
	public static void main(String args []){
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Insira a quantidade de inteiros: ");
		int quant = ler.nextInt();
		
		int inteiros [] = new int [quant];
		
		for (int i =0; i<quant; i++){
		System.out.println("Insira um valor inteiro: ");
		inteiros [i] = ler.nextInt();
		}
		
		
		System.out.println("Insira um valor inteiro qualquer: ");
	    int valor = ler.nextInt();
		
		int cont = conta_menores (inteiros, valor);
		System.out.println("A quantidade de inteiros menores que o valor inserido e: "+cont);
		
	}
	
	
	
	
	public static int conta_menores(int []inteiros, int valor){
		int cont = 0;
		
		for (int i=0; i<inteiros.length; i++){
			if(inteiros[i]<valor){
				cont++;
			}
		}
		
		return cont;
	}
}

