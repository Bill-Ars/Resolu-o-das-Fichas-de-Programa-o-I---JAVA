

import java.util.Arrays;

public class OrdemCrescente {
    public static void main(String args[]) {
        int V[] = {2, 9, 3, 6, 8, 6, 2};

        int aux = 0;

        // Ordenação usando Selection Sort
        for (int i = 0; i < V.length; i++) {
            for (int j = i + 1; j < V.length; j++) { // Corrigido para usar j
                if (V[i] > V[j]) { // Trocar se V[i] for maior que V[j]
                    aux = V[i];
                    V[i] = V[j];
                    V[j] = aux; // Corrigido para trocar com V[j]
                }
            }
        }

        // Impressão do vetor ordenado
        System.out.println("Vetor ordenado(crescente): " + Arrays.toString(V));
		
		
		for (int i = 0; i < V.length; i++) {
            for (int j = i + 1; j < V.length; j++) { // Corrigido para usar j
                if (V[i] < V[j]) { // Trocar se V[i] for maior que V[j]
                    aux = V[i];
                    V[i] = V[j];
                    V[j] = aux; // Corrigido para trocar com V[j]
                }
            }
        }
		
		System.out.println("Vetor ordenado(decrescente): " + Arrays.toString(V));
		
    }
}