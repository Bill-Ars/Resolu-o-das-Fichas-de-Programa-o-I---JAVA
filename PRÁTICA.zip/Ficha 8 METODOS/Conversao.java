   
   
  import java.util.Scanner;
  
  public class Conversao{
	  
	  public static double converterCelsius(double F){
		  double Celsius = (double)5*(F-32)/9;
		  return Celsius;
	  }
	  
	  public static double converterFarenheit(double C){
		  double Farenheit = (double)(9*C/5) + 32;
		  return Farenheit;
	  }
	  
	  public static void main (String args[]){
		  Scanner ler = new Scanner (System.in);
		  
		   
		  
		  System.out.println("Escolha a entrada da temperatura(1 - farenheit; 2 - Celsius): ");
		  int conversao = ler.nextInt();
		  
		  switch (conversao){
			  case 1: System.out.println("Insira o valor em Farenheit: ");
					  double F = ler.nextDouble();
			  
			        double Celsius = converterCelsius(F);
					System.out.println("A conversão em Celsius é: "+Celsius);
						break;
						
			 case 2:  System.out.println("Insira o valor em Celcius: ");
					  double C = ler.nextDouble();
			 
					    double Farenheit = converterFarenheit(C);
						System.out.println("A conversão em Farenheits é: "+Farenheit);
						break;
			default: System.out.println("Opção inválida.");
					 break;
		  }
	  }
	  
  }