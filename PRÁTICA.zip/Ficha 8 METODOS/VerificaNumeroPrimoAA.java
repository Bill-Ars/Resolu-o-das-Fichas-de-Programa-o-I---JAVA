/*PROGRAMA QUE VERIFICA SE UM NUMERO E PRIMO USANDO METODOS*/

import java.util.Scanner;

public class VerificaNumeroPrimoAA {

    // Método para verificar se um número é primo
    public static boolean isPrimo(int numero) {
        if (numero <= 1) {
            return false; // Números menores ou iguais a 1 não são primos
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false; // Se divisível por qualquer número, não é primo
            }
        }
        return true; // Se não for divisível por nenhum número, é primo
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um número para verificar se é primo: ");
        int numero = scanner.nextInt(); // Lê o número fornecido pelo usuário
        
        // Verifica se o número é primo e exibe o resultado
        if (isPrimo(numero)) {
            System.out.println(numero + " é um número primo.");
        } else {
            System.out.println(numero + " não é um número primo.");
        }
        
        scanner.close(); // Fecha o scanner
    }
}