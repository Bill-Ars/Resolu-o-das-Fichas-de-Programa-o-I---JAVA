/*elabore um pograma em java que permite de preencher um vector com 
numeros aleatorios positivos e negativos. 
Desse vector, informe os numeros que sao primos.*/

import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

public class Numero1Div {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        // Solicitar o tamanho do vetor
        System.out.println("Insira o tamanho do vetor: ");
        int quant = scanner.nextInt();
        
        int[] V = new int[quant];
        
        // Preencher o vetor com números aleatórios entre -100 e 100
        for (int i = 0; i < V.length; i++) {
            V[i] = random.nextInt();
        }
        
        // Exibir o vetor gerado
        System.out.println("Vetor: " + Arrays.toString(V));
        
        // Verificar quais números são primos
        System.out.println("Números primos encontrados:");
        for (int i = 0; i < V.length; i++) {
            boolean isPrimo = true; // Assume que o número é primo

            if (V[i] <= 1) {
                isPrimo = false; // Números menores ou iguais a 1 não são primos
            } else {
                // Loop para verificar se o número é divisível por qualquer número de 2 até a raiz quadrada do número
                for (int k = 2; k <= Math.sqrt(V[i]); k++) {
                    if (V[i] % k == 0) {
                        isPrimo = false; // Se divisível por k, não é primo
                        break; // Sai do loop se encontrar um divisor
                    }
                }
            }

            // Exibe o resultado
            if (isPrimo) {
                System.out.println(V[i] + " é um número primo.");
            }else{
				System.out.println(V[i] + " não é um número primo.");
			}
        }

        scanner.close(); // Fecha o scanner para evitar vazamento de recursos
    }
}