/*10. Escreva um método Java para exibir o caractere do meio de uma string.
• Se o comprimento da string for ímpar, haverá dois caracteres do meio.
• Se o comprimento da string for par, haverá um caractere do meio.
*/

public class CaractereDoMeio10 {

    // Método que retorna os caracteres do meio de uma string
    public static String obterCaractereDoMeio(String str) {
        int comprimento = str.length(); // Calcula o comprimento da string

        if (comprimento == 0) {
            return "A string está vazia."; // Retorna mensagem se a string estiver vazia
        }

        int meio = comprimento / 2; // Calcula o índice do meio

        if (comprimento % 2 == 0) {
            // Comprimento par: retorna um único caractere do meio
            return "O caractere do meio é: " + str.charAt(meio - 1); // O caractere anterior ao índice do meio
        } else {
            // Comprimento ímpar: retorna dois caracteres do meio
            return "Os caracteres do meio são: " + str.charAt(meio - 1) + " e " + str.charAt(meio);
        }
    }

    public static void main(String[] args) {
        String[] exemplos = {"exemplo", "exemplos", ""}; // Array de exemplos

        for (String exemplo : exemplos) {
            System.out.println("Para a string: \"" + exemplo + "\"");
            String resultado = obterCaractereDoMeio(exemplo); // Chama o método que retorna o resultado
            System.out.println(resultado); // Exibe o resultado
            System.out.println(); // Linha em branco para melhor legibilidade
        }
    }
}