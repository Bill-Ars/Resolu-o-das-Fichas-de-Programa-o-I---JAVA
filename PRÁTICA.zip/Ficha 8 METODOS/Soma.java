   public class double ExpSoma{
	   
			 public static double Soma =0;
			 
		public static double calcularFracao(int  x, int y){
	
			 double fraccao = (double)x/y;
			 return fraccao;
			}
			
	
		
		public static double Somar (int  x, int y){
			double fracao = calcularfracao(x,y);
		     double  Soma += fracao;
			return Soma;
			}
		
		   public static void main (String args []){
			   int x = 1;
			  int  y = 1;
			   do{
			   Somar(x,y);
			  double x = x +2;
			  double y = y + 1;
			  } while (x<99 && y<50);
			  
		   }
		   
		   System.out.println("Soma: "+Soma);
			  
			   
}