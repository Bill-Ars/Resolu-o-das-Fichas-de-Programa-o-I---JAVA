/*PROGRAMA SIMPLES QUE DETERIMA SE UM NUMERO E PRIMO OU NAO*/


import java.util.Scanner;

public class VerificaNumeroPrimo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um número para verificar se é primo: ");
        int numero = scanner.nextInt(); // Lê o número fornecido pelo usuário

        boolean isPrimo = true; // Assume que o número é primo

        if (numero <= 1) {
            isPrimo = false; // Números menores ou iguais a 1 não são primos
        } else {
            // Loop para verificar se o número é divisível por qualquer número de 2 até a raiz quadrada do número
            for (int i = 2; i <= Math.sqrt(numero); i++) {
                if (numero % i == 0) {
                    isPrimo = false; // Se divisível por i, não é primo
                    break; // Sai do loop se encontrar um divisor
                }
            }
        }

        // Exibe o resultado
        if (isPrimo) {
            System.out.println(numero + " é um número primo.");
        } else {
            System.out.println(numero + " não é um número primo.");
        }
        
        scanner.close(); // Fecha o scanner
    }
}