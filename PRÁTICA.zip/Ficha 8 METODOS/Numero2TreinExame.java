/*Elabore um programa com metodos que te permita de preencher um vector de numeros inteiros. 

O programa deve apresentar o valor mediano (a mediana de estatistica) 

e apagar o maior  eo menor do vector (lista). 

Os valores apagados devem os apresentar em um novo ector ordenado*/



import java.util.Arrays;
import java.util.Scanner;

public class Numero2TreinExame {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

        System.out.println("Digite o tamanho do vetor: ");
        int tamanho = ler.nextInt();

        int inteiros[] = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Número: ");
            inteiros[i] = ler.nextInt();
        }

        System.out.println("Vetor: " + Arrays.toString(inteiros));

        // Ordenar o vetor para calcular a mediana
        int aux = 0;
		
		for(int i = 0; i < inteiros.length; i++){
			for(int j = i+1; j < inteiros.length; j++){   // aux [  ]
				if(inteiros[i]>inteiros[j]){
					aux = inteiros[i];
					inteiros[i] = inteiros[j];
					inteiros[j] = aux;
				}
				
			}
		}
		
		 System.out.println("Vetor ordenado(crescente): " + Arrays.toString(inteiros));

        // Cálculo da mediana
        double M;
        if (tamanho % 2 == 0) {
            M = (inteiros[tamanho / 2 - 1] + inteiros[tamanho / 2]) / 2.0;
            System.out.println("Valor mediano = " + M);
        } else {
            M = inteiros[tamanho / 2];
            System.out.println("Valor mediano = " + M);
        }

        // Encontrar o maior e menor valor do vetor
        int maior = 0; // Inicializa com o primeiro elemento
        int menor = 0; // Inicializa com o primeiro elemento

        for (int i = 1; i < inteiros.length; i++) {
            if (inteiros[i] > maior) {
                maior = inteiros[i];
            }
            if (inteiros[i] < menor) {
                menor = inteiros[i];
            }
        }

        System.out.println("Maior = " + maior);
        System.out.println("Menor = " + menor);

        // Criar um novo vetor sem o maior e o menor
        int[] novoVetor = new int[tamanho - 2];
        int index = 0;

        for (int i = 0; i < inteiros.length; i++) {
            if (inteiros[i] != maior && inteiros[i] != menor) {
                novoVetor[index++] = inteiros[i];
				
            }
        }

        // Exibir o novo vetor
        System.out.println("Novo vetor: " + Arrays.toString(novoVetor));

        // Ordenar os valores removidos
        int[] removidos = {menor, maior};

     
        // Exibir os valores removidos ordenados
        System.out.println("Valores removidos ordenados: " +Arrays.toString(removidos));

        ler.close(); // Fecha o scanner
    }
}