/*9. Crie um programa a base de métodos com métodos que:
a) Preenche um array com nomes de estudantes,
b) Pesquise se um estudante X, existe no array*/

	/*import java.util.Scanner;

	public class Numero9{
		
		public static String[] preencherArrayEstudantes(int tamanho){
			String [] estudantes = new String [tamanho];
			
			for (int i=0; i<tamanho; i++){
				Scanner ler = new Scanner (System.in);
				
				System.out.println("Insira o nome do estudantes: ");
				estudantes [i] = ler.nextLine();
			}
			
			return estudantes;
		}
		
		
	public static String encontrarEstudantes (String [] estudantes, String X){
		
			String result = "Não existe!"; // Assume que não existe até encontrar
        for (int i = 0; i < estudantes.length; i++) {
            if (estudantes[i].equals(X)) { // Usar equals() para comparar strings
                result = "Existe!"; // Armazena "Existe!" se encontrado
                break; // Sai do loop assim que encontrar
            }
        }
        return result; // Retorna o resultado após a busca
    }
	
	
	public static void main (String args []){
		Scanner ler = new Scanner (System.in);
		
		System.out.println("Insira o tamanho do array: ");
		int tamanho = ler.nextInt();
		
		System.out.println("Insira o nome do estudante a procurar: ");
		String X = ler.nextLine();
		
		String [] estudantes = preencherArrayEstudantes(tamanho);
		System.out.println(estudantes);
		
		
		String result = encontrarEstudantes (estudantes, X);
		System.out.println(result);
		
	}
		
} */

import java.util.Scanner;

public class Numero9 {

    // Método para preencher o array com nomes de estudantes
    public static String[] preencherArrayEstudantes(int tamanho) {
        String[] estudantes = new String[tamanho];
        Scanner ler = new Scanner(System.in); // Criar o Scanner fora do loop

        for (int i = 0; i < tamanho; i++) {
            System.out.println("Insira o nome do estudante: ");
            estudantes[i] = ler.nextLine();
        }
        
        return estudantes;
    }

    // Método para encontrar um estudante no array
    public static String encontrarEstudantes(String[] estudantes, String X) {
        String result = "Não existe!"; // Assume que não existe até encontrar
        for (int i = 0; i < estudantes.length; i++) {
            if (estudantes[i].equals(X)) { // Usar equals() para comparar strings
                result = "Existe!"; // Armazena "Existe!" se encontrado
                break; // Sai do loop assim que encontrar
            }
        }
        return result; // Retorna o resultado após a busca
    }

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

        System.out.println("Insira o tamanho do array: ");
        int tamanho = ler.nextInt();
        ler.nextLine(); // Consumir a nova linha pendente

        System.out.println("Insira o nome do estudante a procurar: ");
        String X = ler.nextLine();

        String[] estudantes = preencherArrayEstudantes(tamanho);
        
        // Exibe os nomes dos estudantes
        System.out.println("Estudantes cadastrados:");
         for (int i = 0; i < estudantes.length; i++) {
            System.out.println(estudantes[i]);
        }

        String result = encontrarEstudantes(estudantes, X);
        System.out.println(result);

        ler.close(); // Fecha o scanner para evitar vazamento de recursos
    }
}