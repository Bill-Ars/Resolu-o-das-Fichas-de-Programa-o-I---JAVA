public class Operacoes6 {

    // Método para calcular S1
	
    public static double calcularS1() {
        double S1 = 0.0;
        for (int i = 1; i <= 50; i++) {
            S1 += (2 * i - 1) / (double) i; // (1, 3, 5, ..., 99) / (1, 2, 3, ..., 50)
        }
        return S1;
    }
	

    // Método para calcular S2
    public static double calcularS2() {
        double S2 = 0.0;
        for (int i = 1; i <= 50; i++) {
            S2 += Math.pow(2, i) / (double) (51 - i); // (2, 4, ..., 100) / (50, 49, ..., 1)
        }
        return S2;
    }

    // Método para calcular S3
    public static double calcularS3() {
        double S3 = 0.0;
        for (int i = 1; i <= 10; i++) {
            if (i % 2 != 0) { // Para números ímpares
                S3 += (double) i / Math.pow(i, 2); // Adiciona
            } else { // Para números pares
                S3 -= (double) i / Math.pow(i, 2); // Subtrai
            }
        }
        return S3;
    }

    public static void main(String[] args) {
        double S1 = calcularS1();
        double S2 = calcularS2();
        double S3 = calcularS3();

        System.out.printf("O valor de S1 é: " +S1);
        System.out.printf("O valor de S2 é: " +S2);
        System.out.printf("O valor de S3 é: " +S3);
    }
}