/*11. Escreva um programa que imprime números primos menores que um número informado 
pelo utilizador. Usando métodos.*/

import java.util.Scanner;

public class NumerosPrimos10 {

    // Método para verificar se um número é primo
    public static boolean isPrimo(int numero) {
        if (numero <= 1) {
            return false; // Números menores ou iguais a 1 não são primos
        }
        // Verifica se o número é divisível por qualquer número de 2 até a raiz quadrada do número
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false; // Se divisível por i, não é primo
            }
        }
        return true; // Se não for divisível por nenhum número, é primo
    }

    // Método para imprimir todos os números primos menores que o limite fornecido
    public static void imprimirPrimosMenoresQue(int limite) {
        System.out.println("Números primos menores que " + limite + ":");
        for (int i = 2; i < limite; i++) { // Começa em 2, pois 1 não é primo
            if (isPrimo(i)) { // Verifica se o número i é primo
                System.out.print(i + " "); // Imprime o número primo
            }
        }
        System.out.println(); // Linha em branco após a lista de primos
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um número para encontrar todos os números primos menores que esse número: ");
        int limite = scanner.nextInt(); // Lê o limite fornecido pelo usuário
        
        imprimirPrimosMenoresQue(limite); // Chama o método para imprimir os números primos
        
        scanner.close(); // Fecha o scanner
    }
}