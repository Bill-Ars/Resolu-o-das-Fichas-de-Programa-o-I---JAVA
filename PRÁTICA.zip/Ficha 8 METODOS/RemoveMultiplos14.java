/*. Escreva um programa com um método que recebe uma ArrayList de inteiros e um número 
inteiro, ele remove os múltiplos desse número inteiro informado*/

/*Sim, há várias maneiras de resolver o problema de remover múltiplos de um número inteiro de um ArrayList em Java. Uma abordagem alternativa é criar um novo ArrayList que armazena apenas os elementos que não são múltiplos do número fornecido. Isso evita a necessidade de manipular o índice enquanto percorre a lista original.
Código Java Usando um Novo ArrayList
Aqui está uma implementação que utiliza essa abordagem:*/

import java.util.ArrayList;
import java.util.Scanner;

public class RemoveMultiplos14 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Cria um ArrayList para armazenar os números inteiros
        ArrayList<Integer> numeros = new ArrayList<>();

        // Lê a quantidade de números que o usuário deseja inserir
        System.out.print("Digite a quantidade de números que deseja inserir: ");
        int quantidade = scanner.nextInt();

        // Lê os elementos do ArrayList
        System.out.println("Digite os elementos do ArrayList:");
        for (int i = 0; i < quantidade; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            numeros.add(scanner.nextInt());
        }

        // Lê o número inteiro para remover múltiplos
        System.out.print("Digite um número inteiro para remover seus múltiplos: ");
        int numero = scanner.nextInt();

        // Chama o método para remover múltiplos
        ArrayList<Integer> resultado = removeMultiplos(numeros, numero);

        // Exibe o resultado
        System.out.println("ArrayList após remover os múltiplos de " + numero + ": " + resultado);

        scanner.close(); // Fecha o scanner
    }

    // Método que remove os múltiplos de um número inteiro do ArrayList e retorna um novo ArrayList
    public static ArrayList<Integer> removeMultiplos(ArrayList<Integer> lista, int numero) {
        ArrayList<Integer> novaLista = new ArrayList<>(); // Novo ArrayList para armazenar resultados

        for (int valor : lista) { // Percorre cada elemento da lista original
            if (valor % numero != 0) { // Verifica se não é múltiplo do número
                novaLista.add(valor); // Adiciona à nova lista se não for múltiplo
            }
        }

        return novaLista; // Retorna a nova lista sem os múltiplos
    }
}