/*2. Crie uma classe Calculadora com métodos:
	• Que retorna a soma de 2 valores,
	• Que retorna a subtração de 2 valores,
	• Que retorna a divisão de 2 valores,
	• Que retorna a multiplicação de 2 valores.*/
	
	import java.util.Scanner;

		public class CalculadoraA{
			
			public static int somar (double x, double y){
		    double Soma = x + y;
			return Soma;
			}
			
			public static int subtrair (double x, double y){
			double Subracao = x - y;
			return Subtracao;
			}
			
			public static int dividir (double x, double y){
			double Divisao = (double)x/y;
		    return Divisao;
			}
			
			public static int multiplicar (double x, double y){
			double Multiplicacao = x*y;
			return Multiplicacao;
			}
			
			public static void main(String args[]){
				Scanner ler = new Scanner(System.in);
				
				System.out.println("Insira o primeiro valor: ");
				double x = ler.nextDouble();
				
				System.out.println("Insira o segundo valor: ");
				double y = ler.nextDouble();
				
				 double Soma = somar (x, y);
				 double Subracao = subtrair (x, y);
				 double Divisao = dividir (x, y);
				 double Multiplicacao = multiplicar (x, y);
					
				 System.out.println ("Soma = "+ Soma);
				 System.out.println ("Subtraça = "+ Subtracao);
				 System.out.println ("Divisão = "+ Divisao);
				 System.out.println ("Multiplicação= "+Multiplicacao);
				  
				
			}
			
		}