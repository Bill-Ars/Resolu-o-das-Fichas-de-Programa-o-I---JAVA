
import java.util.Scanner;

public class EqDoSegGrauAA{

    public static boolean validaA(int a) {
        
        return a!=0;
    }

    public static double calcularDelta(int a, int b, int c) {
		double delta = (b*b) -(4*a*c);

        return delta;
    }

    public static void calcularRaizes(int a, int b, int c) {

        

        double sqrtDelta = Math.sqrt(delta);


        double raizesA = (-b + sqrtDelta) / (2 * a);
        double raizesB = (-b - sqrtDelta) / (2 * a);
		
		
       
		}
		
		return raizesA;
		return raizesB;
		

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe o valor de a:");
        int a = scanner.nextInt();
       
        if (validaA(a)) {
            System.out.println("Informe os valor de b e c:");
	    int b = scanner.nextInt();
            int c = scanner.nextInt();
			
			double delta = calcularDelta(a, b, c);
			System.out.println("Delta =" + calcularDelta(a,b,c))
			
			if (delta < 0) {
            System.out.println("A equação não possui raízes reais. Porque Delta é negativo "); // Sem raízes reais
        } else{
			double raizesA = calcularRaizes(a, b,c);
			double raizesB = calcularRaizes(a, b,c);
			
			System.out.println("Raízes: x1 = " + raizesA+ ", x2 = " + raizesB);
			
			
			} 
		else {
            System.out.println("Não é uma equação do segundo grau. Porque a é nulo");
        }

        scanner.close();
    }
}
