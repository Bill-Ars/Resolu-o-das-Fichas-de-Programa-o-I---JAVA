/*Escrever um vector a bae de metodos paerqa:
a) preenche um vector com a idade de varias pessoas.
b) O resultado obtido em a) permite de imprimir a idade e se a pessoa pode votar, sabendo que:

1. ate 16 anos, nao pode votar
2. entre 18 e 18 ou mais que 65, e faculativo.
3. entre 18 e 65,  eobrigatorio.

Dos resultados  obtidos, criar um arrayist que possua a idade dos que devem obrigatoriamente votar.*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ProgramaAULAEXAMES{
    
    // Método para preencher um vetor com as idades
    public static int[] vetorIdades(int quant) {
        int[] V = new int[quant];
        Scanner scanner = new Scanner(System.in);
        
        for (int i = 0; i < quant; i++) {
          System.out.println("Insira as idades: ");
            V[i] = scanner.nextInt();
        }
        
        return V;
    }
    
    // Método para verificar a idade e imprimir a situação de voto
	
	/* poderiamos usar   public static String   comparar (int []V){
		
		
	}*/
	
    public static String comparar(int []V){
		String resultado;
        
        for (int i = 0; i < quant; i++) {
            if (idade < 16) {
                resultado = "Nao pode voltar";
            } else if (idade >= 18 && idade <= 65) {
                resultado = "facultativo votar";
               
            } else {
                resultado = "obrigatorio votar";
            }
        }
        
        return resultado;
    }
	
	public static ArrayList<Integer> obrigatorioVotar(int[]V){
		ArrayList<Integer>obrigatorioVotar = new ArrayList<>();                                                                                                                                                                                                                                                                                                                                                                                                                  
	}
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Quantas pessoas você deseja cadastrar? ");
        int quant = scanner.nextInt();
        
        int[] idades = vetorIdades(quant);
		ArrayList<Integer>obrigatorioVotar= comparar(V);
       
        
        System.out.println("\nIdades das pessoas que devem votar obrigatoriamente:"+idades);
        System.out.println(obrigatorioVotar); 
    }
}