import java.util.Scanner;

public class Volume{
	public static double calcularAreaBase (double r){
		double Abase = Math.PI * Math.pow(r, 2);
		return Abase;
	}
	
	public static double calcularVolume(double Abase, double h){
		double Volume = Abase*h;
		return Volume;
	}
		
	
	public static void main (String args []){
	 Scanner ler = new Scanner (System.in);
		System.out.println("raio: ");
		double r = ler.nextDouble();
		System.out.println("altura: ");
		double h = ler.nextDouble();
		
		double Abase = calcularAreaBase (r);
		System.out.println("Area da Base = "+Abase);
		
		
		double Volume = calcularVolume(Abase, h);
		System.out.println("Volume = "+Volume);
		
		}
}