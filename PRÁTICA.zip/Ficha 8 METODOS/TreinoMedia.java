import java.util.Scanner;

public class TreinoMedia{
	
	public static int calcularSoma(int x, int y){
		int Soma = x + y;
		return Soma;
	}
	
	public static double calcularMedia (int Soma){
		double Media = (double)Soma/2;
		return Media;
		}
	
	public static void main (String args[]){
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Insira o valor 1: ");
		int x = ler.nextInt();
		
		System.out.println("Insira o valor 2: ");
		int y = ler.nextInt();
		
		int Soma = calcularSoma(x,y);
		System.out.println("A soma = "+Soma);
		
		double Media = calcularMedia(Soma);
		System.out.println("A media = "+Media);
	}
}