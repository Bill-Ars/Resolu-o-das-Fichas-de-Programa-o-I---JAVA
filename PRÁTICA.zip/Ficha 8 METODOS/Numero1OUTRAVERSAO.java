/*1. Crie um método que receba um valor e informe se ele é positivo ou negativo através de um 
retorno com boolean.*/

import java.util.Scanner;

public class Numero1OUTRAVERSAO{
	
	
	
	public static boolean informarPosNeg(int valor){
		return valor > 0;
	}
	
	
	
	public static String result(int valor){
		String result;
		
		if (informarPosNeg(valor)){
			result = "Este numero é positivo";
		}else{
			result = "Este numero é negativo";
		}
		
		return result;
	}
	
	
	
	public static void main (String args[]){
		Scanner ler = new Scanner (System.in);
		
		System.out.println("Insira um numero inteiro qualquer: ");
		 int valor = ler.nextInt();
		 
		 
		 String result = result(valor);
		 System.out.println(result);
				 
		 
	}
}