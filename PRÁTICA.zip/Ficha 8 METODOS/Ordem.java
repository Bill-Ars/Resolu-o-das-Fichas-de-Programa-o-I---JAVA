

public class Ordem{

public static void main(String args[]){

int V [] = {2, 9, 3, 6, 8, 6, 2};

  int aux =0;
  
  for (int i = 0; i< V.length; i++){
  for (int j = 0; i<V.length; i++){
	  if(V[i]<V[j]){
		  aux = V[i];
		  V[i] = V[j];
		  V[i] = aux;
	  }
  }
  }
  
  for (int i =  0; i<V.length; i++){
  System.out.println("Vector ordenado: "+Arrays.toString(V));
  }

}
}