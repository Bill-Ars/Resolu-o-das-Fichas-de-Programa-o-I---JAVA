/*. Escreva um programa com um método que recebe uma ArrayList de inteiros e um número 
inteiro, ele remove os múltiplos desse número inteiro informado*/

import java.util.Scanner;
import java.util.ArrayList;

public class RemoveMultiplos{
	
	public static ArrayList<INTEGER> removerMultiplos(ArrayList<INTEGER> numeros, int valor){
		
	}
	
	public static void main(Strings args[]){
		Scanner ler = new Scanner (System.in);
	
	ArrayList<INTEGER> numeros = new ArrayList<>();
	System.out.println("Insira a quantidade: ");
	int quant = ler.nextInt();
	
	for(int i= 0; i<quant ; i++){
		
	}
		
	}
}