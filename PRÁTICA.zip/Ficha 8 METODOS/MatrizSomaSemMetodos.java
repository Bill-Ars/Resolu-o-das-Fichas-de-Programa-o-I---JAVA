/*
Seja uma matriz n*m, de numeros inteiros, escreva um programa que permite de:

a) Determinar as colunas onde a soma é igual a soma das linhas e deve imprimir a coluna e linha correspondente.

Para testar: M = {{1,1,1}, {2,1,3}, {2,1,3}}

*/

import java.util.Scanner;

public class MatrizSomaSemMetodos {

    public static void main(String[] args) {
        // Definindo a matriz M
        int[][] M = {
            {1, 1, 1},
            {2, 1, 3},
            {2, 1, 3},
        };

        int n = M.length; // Número de linhas
        int m = M[0].length; // Número de colunas

        // Array para armazenar as somas das linhas
        int[] somaLinhas = new int[n];

        // Calcula a soma das linhas
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                somaLinhas[i] += M[i][j];
            }
        }

        // Array para armazenar as somas das colunas
        int[] somaColunas = new int[m];

        // Calcula a soma das colunas
        for (int j = 0; j < m; j++) {
            for (int i = 0; i < n; i++) {
                somaColunas[j] += M[i][j];
            }
        }

        // Verifica se a soma das colunas é igual à soma das linhas e imprime resultados
        System.out.println("Colunas onde a soma é igual à soma das linhas:");
        for (int i = 0; i < n; i++) { // Para cada linha
            for (int j = 0; j < m; j++) { // Para cada coluna
                if (somaLinhas[i] == somaColunas[j]) {
                    System.out.println("Linha: " + (i + 1) + ", Coluna: " + (j + 1));
                    
                    System.out.print("Elementos da coluna " + (j + 1) + ": ");
                    for (int k = 0; k < m; k++) {
                        System.out.print(M[k][j] + " "); // Elementos da coluna j
                    }
                    
                    System.out.print("\nElementos da linha " + (i + 1) + ": ");
                    for (int k = 0; k < n; k++) {
                        System.out.print(M[i][k] + " "); // Elementos da linha i
                    }
                    System.out.println(); // Nova linha após imprimir os elementos
                }
            }
        }
    }
}