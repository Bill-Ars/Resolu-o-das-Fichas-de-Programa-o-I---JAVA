import java.util.Scanner;

public class OperandoExame{

public static double somarEXAME (int n){
	double Soma = 0.0;
	
	for(int i = 1; i<=n;i++){
		Soma += (double)1/2*i;
	}
	return Soma;
}

	public static void main(String args[]){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Insira a quantidades de numeros: ");
		int n = scanner.nextInt();
		
		double Soma = somarEXAME(n);
		System.out.println("Soma e: " +Soma);
	}

}