 /*. Crie uma classe ClassificacaoAluno, que possui métodos que:
• Que determina a soma de 3 notas
• Que determina a média de 3 notas
• Que informa o desempenho do estudante retornando uma String de acordo com as 
regras:
- maior ou igual a 18v: Excelente
- entre 14 e 17: Muito Bom
- entre 12 a 13: Bom
- entre 10 e 11: Suficientes
- menor que 10: Mau*/ 

 import java.util.Scanner;
  
  public class ClassificacaoAluno{
	  
	  public static int somar (int x, int y, int z){
		  int Soma = x + y + z;
		  return Soma;
	  }
	  
	  public static double calcularMedia(int Soma){
		  double Media = (double)Soma/3;
		  return Media;
		  }
		  
		  public static String desempenhoDoEstudante(double Media){
			  
			  String resultado;
			  
			  if(Media<10){
				return resultado = "Mau";  
			  }else if (Media>=10 && Media<11){
				 return resultado = "Suficiente";
			  }else if(Media>=12 && Media<13){
				return resultado = "Bom";  
			  }else if(Media>=14 && Media<17){
				 return resultado = "Muito bom";   
			  }else{
				  return resultado = "Excelente";  
			  }			  
}
		  
	  
		  public static void main (String args []){
		  Scanner ler = new Scanner(System.in);
		  
		  System.out.println("Insira o numero 1");
		  int x = ler.nextInt();
		  
		  System.out.println("Insira o numero 2");
		  int y = ler.nextInt();
		  
		  System.out.println("Insira o numero 3");
		  int z = ler.nextInt();
		  
		  
		  double Media = calcularMedia(Soma);
		  String resultado = desempenhoDoEstudante(Media);
		  
		 
		  
		  
		  System.out.println("Media: "+Media);
		  System.out.println("O resultado é:" +resultado);
		  
		  
	  }
  }