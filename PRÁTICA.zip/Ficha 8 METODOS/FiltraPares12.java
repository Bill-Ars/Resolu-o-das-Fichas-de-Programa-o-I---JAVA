/*12. Escreva um programa com um método filtra_pares que recebe um ArrayList contendo 
números inteiros, e devolve o Array Unidimensional contendo apenas os números pares do 
ArrayList.*/

import java.util.ArrayList;
import java.util.Scanner;

public class FiltraPares12{

    // Método que filtra os números pares de um ArrayList
    public static int[] filtra_pares(ArrayList<Integer> numeros) {
        // Contar quantos números pares existem
        int count = 0;
        for (int i=0; i< numeros.size(); i++) {
            if (numeros.get(i) % 2 == 0) {
                count++; // Incrementa o contador se o número for par
            }
        }

        // Cria um array para armazenar os números pares
        int[] pares = new int[count];
        int index = 0;

        // Adiciona os números pares ao array
        for (int i=0; i< numeros.size(); i++) {
            if (numeros.get(i) % 2 == 0) {
                pares[index] = numeros.get(i); // Adiciona o número par ao array
                index++; // Incrementa o índice
            }
        }

        return pares; // Retorna o array com os números pares
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> numeros = new ArrayList<>(); // Cria um ArrayList para armazenar os números

        System.out.print("Digite a quantidade de números que deseja inserir: ");
        int quantidade = scanner.nextInt(); // Lê a quantidade de números

        // Lê os números do usuário e os adiciona ao ArrayList
        for (int i = 0; i < quantidade; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros.add(scanner.nextInt());
        }

        // Chama o método filtra_pares e armazena o resultado
        int[] pares = filtra_pares(numeros);

        // Exibe os números pares encontrados
        System.out.println("Números pares:");
        for (int index = 0; index<pares.length; index++) {
            System.out.println(pares[index]);
        }
        
        scanner.close(); // Fecha o scanner
    }
}