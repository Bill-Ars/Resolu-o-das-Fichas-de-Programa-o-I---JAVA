/*12. Escreva um programa com um método filtra_pares que recebe um ArrayList contendo 
números inteiros, e devolve o Array Unidimensional contendo apenas os números pares do 
ArrayList.*/ 


 import java.util.Scanner;
 import java.util.ArrayList;
 import java.util.Arrays;
 
 
 public class Progama12{
	 
	 public static ArrayList<INTEGER> encontrarInteiros (int quant){
	 
	 ArrayList<INTEGER> inteiros = new ArrayList<>();
	 Scanner ler = new Scanner(System.in);
	 
	 for(int i=0; i<quant; i++){
		 System.out.println("Insira o numero inteiro: ");
		 int valor = ler.nextInt();
		 inteiros.add(valor);
		 }
		 
		 return inteiros;
		 
	}
	
	public static int[] filtra_pares(ArrayList<INTEGER> inteiros){
		
		for(int i=0; i<inteiros.size(); i++){
		 int cont = 0;
		 if(inteiros.get(i)%2 = 0){
			 cont++;
		 }
	 }
		
		 int [] Array = new int [cont];
		 int f=0;
	 
	 for(int i=0; i<quant; i++){
		  if(inteiros.get(i)%2 == 0){
			  inteiros.get(i) = Array[f];
			  f++;
		  }
	 }
	return Array;	
}
		 
     
	 
	 
	 
	
	 
		 
	 public static void main(String args[]){
		 
		 Scanner ler = new Scanner (System.in);
		 
		 System.out.println("tamanho do ArrayList: ");
		 int quant = ler.nextInt();
		 
		 ArrayList<INTEGER> inteiros = encontrarInteiros(quant);
		 System.out.println("Os numeros inteiros sao: ");
		 for(int i=0; i<inteiros.size(); i++){
			  System.out.println(inteiros.get(i));
		 }
		 
		 
		 int [] Array = filtra_pares(inteiros);
		 System.out.println("Os numeros pares sao: "+Arrays.toString(Arrays));
	 }
	 
 }