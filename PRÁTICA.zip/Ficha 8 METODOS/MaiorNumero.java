/*Crie uma classe Maior, que possui um método que retorna o maior entre 3 números.
*/

import java.util.Scanner;

public class MaiorNumero{
	
	
	public static int encontrarMaior(int x, int y, int z){
		int maior;
		
		if(x>y && x>z){
			maior = x;
		} else if (y>x && y>z){
			maior = y;
		}else {
			maior = z;
		}
		
	    return maior;
	 
	}
	
	public static void main (String args []){
	 Scanner ler = new Scanner (System.in);
	 
	 System.out.println("numero 1: ");
	 int x = ler.nextInt();
	 System.out.println("numero 2: ");
	 int y = ler.nextInt();
	 System.out.println("numero 3: ");
	 int z = ler.nextInt();
	 
	 int maior = encontrarMaior (x,y,z);
	 
	 System.out.println("Maior numero = "+maior);
	 
	 
	}
}