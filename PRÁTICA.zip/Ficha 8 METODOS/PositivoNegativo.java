/*1. Crie um método que receba um valor e informe se ele é positivo ou negativo através de um 
retorno com boolean.*/

import java.util.Scanner;

public class PositivoNegativo{
	
	public static boolean informarPosNeg(int valor){
		return valor > 0;
	}
	
	public static void main (String args[]){
		Scanner ler = new Scanner (System.in);
		
		System.out.println("Insira um numero inteiro qualquer: ");
		 int valor = ler.nextInt();
		 
		 
		 if (informarPosNeg(valor)){
			 System.out.println("O numero inserido e positivo.");
		 }else{
			System.out.println("O numero inserido e negativo."); 
		 }
		 
		 
		 System.out.println("O bolean e: "+informarPosNeg(valor));  //true or false
		 
		 
	}
}