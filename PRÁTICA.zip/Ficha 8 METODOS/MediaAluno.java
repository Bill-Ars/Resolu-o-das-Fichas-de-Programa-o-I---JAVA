	/*Faça um método que calcule a média de um aluno de acordo com o critério: 
	𝑴𝒆𝒅𝒊𝒂 = 𝑴𝒕𝟏 𝒙 𝟏𝟓% + 𝑻𝟏 𝒙 𝟑𝟓% + 𝑴𝒕𝟐 𝒙 𝟏𝟓% + 𝑻𝟐 𝒙 𝟑𝟓%. 
	Além disso, faça um outro método que informe o status do aluno de acordo com as 
	instruções a seguir: 
	• Nota acima de 13 à “Aprovado” 
	• Nota entre 10 e 13 à Conceito “Verificação Suplementar” 
	• Nota abaixo de 10 à Conceito “Reprovado”
	*/
	import java.util.Scanner;
	
	public class MediaAluno{
		
		public static double calcularMedia(double Mt1, double T1, double Mt2, double T2){
			double Media = (Mt1 + Mt2)*(double)15/100 + (T1 + T2)*(double) 35/100;
			return Media;
		}
		
		public static String verificarStatusAluno(double Media){
			String status;
			
		if(Media<10){
			return status = "Reprovado";
		}else if(Media > 10 && Media<=13){
			return status = "Verificacao suplementar";
		}else {
			return status = "Aprovado";
		}
	
	}
	
	
	public static void main (String args []){
		Scanner ler = new Scanner (System.in);
		
		System.out.println("Insira as notas(Mt1 e Mt2; T1 e T2): ");
		
		double Mt1 = ler.nextDouble();
		double Mt2 = ler.nextDouble();
		double T1 = ler.nextDouble();
		double T2 = ler.nextDouble();
		
		double Media = calcularMedia(Mt1, T1, Mt2,T2);
		String status = verificarStatusAluno(Media);
		
		System.out.println("A sua media é: "+Media+" e o seu status é: " +status);
	}

}