/*Escrever um vector a bae de metodos paerqa:
a) preenche um vector com a idade de varias pessoas.
b) O resultado obtido em a) permite de imprimir a idade e se a pessoa pode votar, sabendo que:

1. ate 16 anos, nao pode votar
2. entre 18 e 18 ou mais que 65, e faculativo.
3. entre 18 e 65,  eobrigatorio.

Dos resultados  obtidos, criar um arrayist que possua a idade dos que devem obrigatoriamente votar.*/

import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;


public class ProgramaEXAMESS {
    
    // Método para preencher um vetor com as idades
    public static int[] preencherIdades(int quantidade) {
        int[] idades = new int[quantidade];
        Scanner ler = new Scanner(System.in);
        
        for (int i = 0; i < quantidade; i++) {
            System.out.print("Insira a idade da pessoa " + (i + 1) + ": ");
            idades[i] = ler.nextInt();
        }
        
        return idades;
    }
    
    // Método para verificar a situação de voto e imprimir os resultados
    public static String verificarVoto(int[] idades) {

		
		
        for (int i = 0; i < idades.length; i++) {
			 // IMPORTANTE: 

            if (idades[i] < 16) {
              String  result = "Idade: " + idades[i] + " - Não pode votar.";
            } else if ((idades[i] >= 18 && idades[i] <= 65)) {
               String  result = "Idade: " + idades[i] + " - Votar é obrigatório.";
            } else {
              String   result = "Idade: " + idades[i] + " - Votar é facultativo.";
            }
			
        }
		
		return result;
		
    }
    
    // Método para obter as idades que devem votar obrigatoriamente
    public static ArrayList<Integer> verificarVotoObrigatorio(int[] idades) {
        ArrayList<Integer> obrigatorioVotar = new ArrayList<>();
        for (int i = 0; i < idades.length; i++) {
            if (idades[i]>=18 && idades[i]<65){
                obrigatorioVotar.add(idades[i]);
            }
        }
        return obrigatorioVotar;
    }
    
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.print("Insira a quantidade de pessoas: ");
        int quantidade = ler.nextInt();
        
        int[] idades = preencherIdades(quantidade);
        
        System.out.println("As idades são: " + Arrays.toString(idades));
        
        String result = verificarVoto(idades);
		System.out.println(result);
		
        
        ArrayList<Integer> obrigatorioVotar = verificarVotoObrigatorio(idades);
        System.out.println("As idades que votam obrigatoriamente: " + obrigatorioVotar);
        
        ler.close();
    }
}