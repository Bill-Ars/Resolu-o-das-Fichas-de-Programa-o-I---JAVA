import java.util.Scanner;

public class MaiorNumero{
	static int maior;
	
	public static void encontrarMaior(int x, int y, int z){
		if(x>y && x>z){
			maior = x;
		} else if (y>x && y>z){
			maior = y;
		}else {
			maior = z;
		}
		
	    System.out.println("O maior entre eles e: "+maior);
	 
	}
	
	public static void main (String args []){
	 Scanner ler = new Scanner (System.in);
	 
	 System.out.println("numero 1: ");
	 int x = ler.nextInt();
	 System.out.println("numero 2: ");
	 int y = ler.nextInt();
	 System.out.println("numero 3: ");
	 int z = ler.nextInt();
	 
	 encontrarMaior (x,y,z);
	 
	 
	}
}