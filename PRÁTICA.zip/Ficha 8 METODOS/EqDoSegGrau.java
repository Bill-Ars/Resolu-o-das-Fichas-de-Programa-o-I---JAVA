
import java.util.Scanner;

public class EqDoSegGrau {

    // Valida se 'a' é diferente de zero
    public static boolean validaA(int a) {
        return a != 0;
    }

    // Calcula o valor de delta
    public static double calcularDelta(int a, int b, int c) {
        return (b * b) - (4 * a * c);
    }

    // Calcula as raízes da equação
    public static double[] calcularRaizes(int a, int b, int c) {
        double delta = calcularDelta(a, b, c);

        if (delta < 0) {
            return null; // Sem raízes reais
        }else{

        double sqrtDelta = Math.sqrt(delta);
        double[] raizes = new double[2];

        raizes[0] = (-b + sqrtDelta) / (2 * a); // Primeira raiz
        raizes[1] = (-b - sqrtDelta) / (2 * a); // Segunda raiz

        return raizes;
		}
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Informe o valor de a:");
        int a = scanner.nextInt();
       
        if (validaA(a)) {
            System.out.println("Informe os valores de b e c:");
            int b = scanner.nextInt();
            int c = scanner.nextInt();

            double[] raizes = calcularRaizes(a, b, c);
            double delta = calcularDelta(a, b, c);

            if (raizes != null) {
                System.out.printf("Delta = %.2f%n", delta);
                System.out.printf("Raízes: x1 = %.2f, x2 = %.2f%n", raizes[0], raizes[1]);
            } else {
                System.out.printf("A equação não possui raízes reais. Delta é negativo: %.2f%n", delta);
            }
        } else {
            System.out.println("Não é uma equação do segundo grau. O valor de 'a' não pode ser zero.");
        }

        scanner.close(); // Fecha o scanner para liberar recursos
    }
}
