import java.util.Scanner;

public class Divisores{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira um numero inteiro: ");
		int num = scanner.nextInt();
		int i;
		
			for (i=1;i<=num;i++){
				if (num % i == 0){
				
				System.out.println(i);
				}
			}
	}
}