/* Class Random: import java.util.Random;
A classe Random proporciona-nos a geração de números aleatórios.
Os números aleatórios são utilizados de diversas formas em programas 
de computador. Eles são importantes no desenvolvimento de jogos, na 
área de segurança de informações (ex: para gerar senhas ou textos de 
campos captcha). */

/* O método nextInt(int x) da classe java.util.Random em Java 
é utilizado para gerar um número aleatório do tipo int 
dentro de um intervalo específico.  */

import java.util.Random;

public class RandomExample {
    public static void main(String[] args) {
        // Cria uma instância da classe Random
        Random random = new Random();

        // Gera um número aleatório entre 0 e 99
        int randomNumber = random.nextInt(100); // 100 é exclusivo
        System.out.println("Número aleatório entre 0 e 99: " + randomNumber);
    }
}