 /* 1. Usando nextInt() sem Argumentos
Este método gera um número inteiro aleatório sem limites.
*/

import java.util.Random;

public class RandomExample2{
    public static void main(String[] args) {
        Random random = new Random();
        
        // Gera um número inteiro aleatório
        int randomNumber = random.nextInt();
        System.out.println("Número aleatório gerado: " + randomNumber);
    }
}