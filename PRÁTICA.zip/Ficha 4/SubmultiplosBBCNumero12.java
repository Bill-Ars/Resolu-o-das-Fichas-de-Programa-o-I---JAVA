/* 2. Elabore um método em Java que tenha como entrada um número inteiro e forneça como 
saída um conjunto de 15 elementos contendo os seus submúltiplos*/


import java.util.Scanner;

public class SubmultiplosBBCNumero12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
        System.out.println("Insira um número: ");
        int numero = scanner.nextInt();  
        
        int[] submult = new int[numero];  
        
        
        int count = 0;  
		int b=0;
        
        // Loop para encontrar os submúltiplos
        for (int i= 0; i<numero.length; i++) {
			b++;
            if (numero % b == 0) {  // Verifica se b é um submúltiplo de numero
                submult[i] = b; // Armazena o submúltiplo no vetor
                count++;            // Incrementa o contador
            }
        }
        
        // Verifica se foram encontrados 15 submúltiplos
        if (count != 15) {
            System.out.println("O número não tem 15 submúltiplos. Insira um número maior. Obrigado!");
        } else {
            System.out.println("Os 15 submúltiplos de " + numero + " são:");
            for (int i = 0; i < submult.length; i++) {
                System.out.println(submult[i]);	
            }
        }
        
        scanner.close(); // Fecha o scanner para evitar vazamento de recursos
    }	
}