import java.util.Random;

public class RandomFloatExample {
    public static void main(String[] args) {
        // Cria uma instância da classe Random
        Random random = new Random();

        // Gera e imprime um número float aleatório entre 0.0 e 1.0
        float randomFloat = random.nextFloat();
        System.out.println("Número aleatório float: " + randomFloat);
    }
}