/*Faça um programa que permite de contabilizar quantas vezes a letra
“a” aparece em uma frase informada pelo usuário*/

import java.util.Scanner;

public class ContarAAS{
	public static void main (String[]args){
	  Scanner scanner = new Scanner(System.in);
	  
	  System.out.print("frase: ");
	  String frase = scanner.nextLine();
	  
	  int contar = 0;
	  
	  for( int i = 0; i < frase.length(); i++){
		  if(frase.charAt(i)== 'a'||frase.charAt(i)=='A'){
			  contar ++;
	        }
		}
	  
		System.out.println("Possui: "+contar+" a");
	}
}
	  