import java.util.Scanner;

public class Valor{
	public static void main (String[]args){
	  Scanner scanner = new Scanner(System.in);
	  
	  System.out.print("Insira um numero de controle: ");
	  int num = scanner.nextInt();
	  
	  int c = 1;
	  int P = 1;
	  
	  do{
		  System.out.println("Insira o seu numero de teste: ");
		  int number = scanner.nextInt();
		  
		  if(number%num=0){
			  System.out.println("O valor e divisivel por pelo numero");
			  P = P*number;
			  c++;
			  }
	    }while (c <= 3);
	  
	  System.out.println("O produto dos 3 numeros e: "+P);
	  
	  
	}
}