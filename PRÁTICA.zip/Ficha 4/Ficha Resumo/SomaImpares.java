public class SomaImpares {
    public static void main(String[] args) {
        int soma = 0; // Variável para armazenar a soma
        int contador = 0; // Contador para rastrear quantos ímpares foram encontrados

        // Loop para percorrer o intervalo de 0 a 20
        for (int i = 0; i <= 20; i++) {
            // Verifica se o número é ímpar
            if (i % 2 != 0) {
                soma += i; // Adiciona o número ímpar à soma
                contador++; // Incrementa o contador

                // Verifica se já encontramos 7 números ímpares
                if (contador == 7) {
                    break; // Sai do loop se 7 ímpares foram encontrados
                }
            }
        }

        // Exibe o resultado
        System.out.println("A soma dos primeiros 7 números ímpares no intervalo de [0, 20] é: " + soma);
    }
}