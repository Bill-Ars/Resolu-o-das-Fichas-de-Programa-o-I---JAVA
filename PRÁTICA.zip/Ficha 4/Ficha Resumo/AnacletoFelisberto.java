/*. Anacleto tem 1,50m e cresce 2 centímetros por ano, enquanto Felisberto tem 1,10m e cresce 
3 centímetros por ano. Construa um programa que calcule e apresente quantos anos serão 
necessários para que Felisberto seja maior que Anacleto.*/

public class AnacletoFelisberto{
    public static void main(String[] args) {
      
		
		double Anacleto = 1.50;
		double Felisberto = 1.10;
		int Ano = 0;
		
		while(Felisberto <= Anacleto){
			Anacleto += 0.02;
			Felisberto += 0.03;
			Ano += 1;
			}
		System.out.println("O tempo preciso para Felisberto ser maior que Anacleto e de: "+Ano+" anos");
	}
}