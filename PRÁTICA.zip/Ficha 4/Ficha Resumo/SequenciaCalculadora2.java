/*Faça um programa para calcular e imprimir a seguinte soma:
37 × 38 ÷ 1 + 36 × 37 ÷ 2 + 35 × 36 ÷ 3 + ... + 1 × 2 ÷ 37*/


public class SequenciaCalculadora2 {
    public static void main(String[] args) {
        double resultado = 0.0; // Variável para armazenar o resultado
		
              for (int i=1;i<=37;i++){
				  double a = 37 - (i-1);
				  
				  double b = 38 - (i-1);
				  
				  int denominador = i;
				  
				  resultado += a*b/i;
				  
				  System.out.println(a+"x"+b+"/"+i);
			  }
			  System.out.println(resultado);
	}
}
		