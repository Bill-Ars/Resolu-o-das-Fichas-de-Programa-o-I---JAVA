public class SequenciaCalculadora {
    public static void main(String[] args) {
        double resultado = 0.0; // Variável para armazenar o resultado

        // Loop para calcular os primeiros 50 termos da sequência
        for (int i = 1; i <= 50; i++) {
            // Calcula o numerador
            int numerador = 1000 - (i - 1) * 3; // Decrementa o numerador em 3 a cada iteração
            // Calcula o denominador
            int denominador = i; // O denominador é igual ao índice do loop
            
            // Alterna entre adição e subtração
            if (i % 2 == 1) { // Se i é ímpar, adiciona
                resultado += (double) numerador / denominador;
            } else { // Se i é par, subtrai
                resultado -= (double) numerador / denominador;
            }
        }

        // Exibe o resultado final
        System.out.printf("O resultado dos primeiros 50 números da sequência é: %.6f%n", resultado);
    }
}