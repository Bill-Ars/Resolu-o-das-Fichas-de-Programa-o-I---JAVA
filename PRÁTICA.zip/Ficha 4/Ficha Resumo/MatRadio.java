/*Um determinado material radioactivo perde metade de sua massa a cada 50 segundos. Dada 
a massa inicial, em gramas, faça um programa que determine o tempo necessário para que 
essa massa se torne menor que 0,05 gramas*/

import java.util.Scanner;

public class MatRadio{
	public static void main (String []args){
		Scanner scanner = new Scanner (System.in);
		
		System.out.print("Insira a massa inicial: ");
		double massa = scanner.nextDouble();
		
		int tempo = 0;
		
		while(massa >= 0.05){
			massa = massa/2;
			tempo = tempo +50;
			
		}
		System.out.println("O tempo necessario(em segundos) e: "+tempo);
	}
}
		