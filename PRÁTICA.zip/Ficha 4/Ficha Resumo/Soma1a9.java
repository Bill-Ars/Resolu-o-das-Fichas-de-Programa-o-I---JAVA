public class Soma1a9{
    public static void main(String[] args) {
        
		int soma = 0; // Variável para armazenar a soma
      

        // Loop para percorrer o intervalo de 0 a 20
        for (int i = 1; i <= 9; i++) {
            
                soma += i;
            }

        // Exibe o resultado
        System.out.println("A soma dos numeros no intervalo de 1 a 9: " +soma);
    }
}