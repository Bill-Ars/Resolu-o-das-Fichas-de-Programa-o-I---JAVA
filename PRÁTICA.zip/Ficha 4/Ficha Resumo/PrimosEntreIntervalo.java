/*Número primo é aquele que só é divisível por ele mesmo e pelo número 1. Faça um 
programa que determine e imprima os números primos compreendidos entre um intervalo 
fornecido pelo usuário.*/

import java.util.Scanner;

public class PrimosEntreIntervalo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita os valores de A e B ao usuário
        System.out.print("Digite o primeiro valor: ");
        int a = scanner.nextInt();
        System.out.print("Digite o segundo valor: ");
        int b = scanner.nextInt();

        // Verifica se A é menor que B
        if (a > b) {
            System.out.println("O primeiro valor deve ser menor ou igual ao segundo valor.");
        } else {
            System.out.println("Números primos entre " + a + " e " + b + ":");
            for (int i = a; i <= b; i++) {
                // Verifica se o número é primo
                int somaDiv = 0; // Contador de divisores
                for (int j = 1; j <= i; j++) {
                    if (i % j == 0) {
                        somaDiv++; // Incrementa o contador se j for divisor de i
                    }
                }

                // Se o número tiver exatamente 2 divisores, é primo
                if (somaDiv == 2) {
                    System.out.println(i);
                }
            }
        }

        // Fecha o scanner
        scanner.close();
    }
}