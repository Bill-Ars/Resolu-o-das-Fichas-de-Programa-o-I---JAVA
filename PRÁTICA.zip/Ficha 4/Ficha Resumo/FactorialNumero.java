//Faça um programa que imprima os factoriais de 1 a 10.

public class FactorialNumero{
    public static void main(String[] args) {
		
		int factorial = 1;
		
		for (int i = 1; i <= 10; i++){
			factorial *= i;
			System.out.println(factorial);
		}
		
		
	}
}