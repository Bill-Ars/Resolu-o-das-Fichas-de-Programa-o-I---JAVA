import java.util.Scanner;

public class RendimentoPoupanca {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário o valor depositado na poupança
        System.out.print("Digite o valor depositado na poupança: ");
        double valorDeposito = scanner.nextDouble();

        // Taxa de juros mensal
        double taxaJuros = 0.005; // 0,5% ao mês

        // Exibe o cabeçalho da tabela
        System.out.printf("Mês", "Valor com Juros");
        System.out.println("-------------------------");

        // Loop para calcular e exibir o rendimento mês a mês
        for (int mes = 1; mes <= 12; mes++) {
            // Calcula o rendimento para o mês atual
            valorDeposito += valorDeposito * taxaJuros;

            // Exibe o mês e o valor com juros
            System.out.printf("%-10d %-15.2f%n", mes, valorDeposito);
        }

        scanner.close(); // Fecha o scanner
    }
}