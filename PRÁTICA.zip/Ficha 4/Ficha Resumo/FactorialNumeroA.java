import java.util.Scanner;

public class FactorialNumeroA{
    public static void main(String[] args) {
	 Scanner scanner = new Scanner (System.in);
		
		System.out.print("Insira um numero para o calculo: ");
		int n = scanner.nextInt();
		
		
		int factorial = 1;
		
		for (int i = 1; i <= n; i++){
			factorial *= i;
			
		}
		System.out.println("O factorialdo numero e: "+factorial);
		
	}
}