import java.util.Scanner;

public class SomaCubosNumerosPares {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita os valores de A e B ao usuário
        System.out.print("Digite o valor de A: ");
        int A = scanner.nextInt();
        System.out.print("Digite o valor de B: ");
        int B = scanner.nextInt();

        // Verifica se B é maior que A
        if (B <= A) {
            System.out.println("Erro: B deve ser maior que A.");
            return;
        }

        long soma = 0; // Variável para armazenar a soma dos cubos

        // Loop para calcular a soma dos cubos dos números pares
        for (int i = A; i <= B; i++) {
            if (i % 2 == 0) { // Verifica se o número é par
                soma += (long) Math.pow(i, 3); // Adiciona o cubo do número à soma
            }
        }

        // Exibe o resultado
        System.out.println("A soma dos cubos dos números pares entre " + A + " e " + B + " é: " + soma);

        scanner.close(); // Fecha o scanner
    }
}