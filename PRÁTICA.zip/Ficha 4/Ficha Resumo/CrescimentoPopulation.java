/* Supondo que a população de um país A seja da ordem de 80.000 habitantes com uma taxa 
anual de crescimento de 3% e que a população de B seja 200.000 habitantes com uma taxa 
de crescimento de 1,5%. Faça um programa que calcule e imprima o número de anos 
necessários para que a população do país A ultrapasse ou iguale a população do país B, 
mantidas as taxas de crescimento.*/

public class CrescimentoPopulation{
    public static void main(String[] args) {
		
		double popA = 80000;
		double popB = 200000;
		
		int tempo = 0;
		
		while(popA<popB){
			 popA = popA+popA*0.03;
		     popB =popB+popB*15/100;
			 tempo ++;
			 
			 
		}
		System.out.println("O número de anos para que a população A seja maior que B é de: "+tempo+" anos");
	}
}