

import java.util.Scanner;

public class BasExpoente{
    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira a base: ");
		int base = scanner.nextInt();
		
		System.out.print("Insira o expoente: ");
		int exp = scanner.nextInt();
		int i;
		
		int P=1;
		
		for(i=1;i<=exp;i++){
			P = P*base;
			}
			
		System.out.println("Resultado: "+P);
	}
}
