public class SomaInteiros {
    public static void main(String[] args) {
        int soma = 0; // Variável para armazenar a soma

        // Loop para somar os números de 1 a 100
        for (int i = 1; i <= 100; i++) {
            soma += i; // Adiciona o número atual à soma
        }

        // Exibe o resultado
        System.out.println("A soma dos números inteiros de 1 a 100 é: " + soma);
    }
}