import java.util.Random;

public class RandomExample5 {
    public static void main(String[] args) {
        // Cria uma instância da classe Random
        Random random = new Random();

        // Gera um número aleatório entre 0 e 99
        int randomNumber = random.nextInt(5,15); // 100 é exclusivo
        System.out.println("Número aleatório entre 0 e 99: " + randomNumber);
    }
}