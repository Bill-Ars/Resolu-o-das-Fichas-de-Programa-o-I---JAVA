//Crie uma classe para calcular a raiz quadrada dos números 900 e 30.25.

public class SquareRoot900et30{
    public static void main(String[] args) {
		
		double a = 900;
		double b = 30.25;
		
		double Raiz1 = Math.sqrt(a);
		double Raiz2 = Math.sqrt(b);
		
		System.out.println("A raiz quadrada de "+a+" : "+Raiz1);
		System.out.println("A raiz quadrada de "+b+" : "+Raiz2);
	}
}
		