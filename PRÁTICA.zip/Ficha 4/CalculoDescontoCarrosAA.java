/*Faça um programa que calcule e exiba o valor do desconto e o valor a ser pago pelo 
cliente de vários carros. O desconto deverá ser calculado de acordo com o ano do 
veículo. Até 2000 desconto de 12% e acima de 2000 desconto de 7%. O sistema deverá 
perguntar se deseja continuar calculando novos descontos até que a resposta seja: "( N ) 
Não )". Informar o total de carros com ano até 2000 e o total de carros no geral.*/

import java.util.Scanner;

public class CalculoDescontoCarrosBBB {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String continuar; // Corrigido para 'continuar' em minúsculas
        int totalCarros = 0;
        int totalCarrosAte2000 = 0;

        do {
            System.out.print("Digite o ano do veículo: ");
            int anoVeiculo = scanner.nextInt();
            System.out.print("Digite o valor do carro: R$ ");
            double valorCarro = scanner.nextDouble();
            scanner.nextLine(); // Limpa o buffer do scanner

            double desconto;
            if (anoVeiculo <= 2000) {
                desconto = valorCarro * 0.12; // 12% de desconto
                totalCarrosAte2000++;
            } else {
                desconto = valorCarro * 0.07; // 7% de desconto
            }

            double valorAPagar = valorCarro - desconto;

            // Exibe os resultados
            System.out.printf("Desconto: R$ %.2f%n", desconto);
            System.out.printf("Valor a ser pago: R$ %.2f%n", valorAPagar);

            totalCarros++;

            System.out.print("Deseja calcular o desconto para outro carro? (S para sim / N para não): ");
            continuar = scanner.nextLine(); // Corrigido para usar scanner.nextLine()

        } while (!continuar.equalsIgnoreCase("N")); // Corrigido para comparar com "N"

        // Exibe o total de carros
        System.out.println("Total de carros no geral: " + totalCarros);
        System.out.println("Total de carros com ano até 2000: " + totalCarrosAte2000);

        scanner.close();
    }
}