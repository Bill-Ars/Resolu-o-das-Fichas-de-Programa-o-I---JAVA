public class tamanho {
    public static void main(String[] args) {
        int[] numeros = {1, 2, 3, 4, 5};
        int tamanho = numeros.length; // Obtém o tamanho do array
        System.out.println("O tamanho do array é: " + tamanho);
    }
}