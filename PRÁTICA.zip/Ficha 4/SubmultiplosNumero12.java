/*. Elabore um método em Java que tenha como entrada um número inteiro e forneça como 
saída um conjunto de 15 elementos contendo os seus submúltiplos.
*/


import java.util.Scanner;

public class SubmultiplosNumero12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que digite um número inteiro
        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt();

        // Cria um vetor para armazenar os submúltiplos
        int[] submultiplos = new int[15];

        // Preenche o vetor com os submúltiplos do número
        for (int i = 0; i < submultiplos.length; i++) {
            submultiplos[i] = numero * (i + 1); // Calcula o submúltiplo
        }

        // Exibe os submúltiplos
        System.out.println("Os 15 submúltiplos de " + numero + " são:");
        for (int i = 0; i < submultiplos.length; i++) {
            System.out.println(submultiplos[i]);
        }

        scanner.close(); // Fecha o scanner para evitar vazamento de recursos
    }
}