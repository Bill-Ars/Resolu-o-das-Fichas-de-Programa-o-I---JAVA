import java.util.Scanner;

public class Soma{
	public static void main (String[]args){
	  Scanner scanner = new Scanner(System.in);
	  
	  System.out.print("Insira o limite: ");
	  double N = scanner.nextDouble();
	  
	  double S = 0;
	 
	  for(int i=0;i<N;i++){
		  double numerador = Math.pow(final char x,2*i);
		  double denominador = Math.pow(2,i);
		  
		  double S = S + numerador/denominador;
	  }
	  System.out.println("A soma e: "+S);
	}
}