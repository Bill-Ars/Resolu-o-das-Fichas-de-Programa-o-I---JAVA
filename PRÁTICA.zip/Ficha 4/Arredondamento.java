/*Crie uma classe para fazer o arredondamento dos seguintes valores: 5.2, 5.6 e -5.8 para o 
valor inteiro mais próximo.*/

public class Arredondamento{
    public static void main(String[] args) {
		
		double a = 5.1;
		double b = 5.6;
		double c = -5.8;
		
		System.out.println("a mais proximo e: "+Math.ceil(a));
		System.out.println("b mais proximo e: "+Math.ceil(b));
		System.out.println("c mais proximo e: "+Math.ceil(c));
	}
}