import java.util.Scanner; 

public class CaixaDagua {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira o valor do lado da caixa d'água
        System.out.print("Digite o valor do lado da caixa d'água (em metros): ");
        double lado = scanner.nextDouble(); // Lê o valor do lado

        // Calcula o volume da caixa d'água usando Math.pow
        double volume = Math.pow(lado, 3); // Calcula lado³

        // Exibe o resultado
        System.out.println("O volume da caixa d'água é: " +volume);
		
		
		System.out.println("O resultado inteiro anterior de "+volume+" é "+Math.floor(volume));

        // Fecha o scanner
        scanner.close();
    }
}