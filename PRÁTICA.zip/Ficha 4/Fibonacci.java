/*Exiba os 50 primeiros números da sequência de Fibonacci (1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 
89, 144, 233, 377, ...)*/

public class Fibonacci {
    public static void main(String[] args) {
        int n = 50; // Número de termos desejados na sequência

        long first = 1; // Primeiro número da sequência
        long second = 1; // Segundo número da sequência

        // Exibir os primeiros dois números
        System.out.println("Os primeiros números da sequência de Fibonacci são: ");
		System.out.println(first);
		System.out.println(second);
		

        // Calcular e exibir os próximos números da sequência
        for (int i = 3; i <= n; i++) {
            long next = first + second; // O próximo número é a soma dos dois anteriores
            System.out.println(next); // Exibir o próximo número

            // Atualizar os valores para o próximo cálculo
            first = second;
            second = next;
        }
    }
}