/*Imprima a seguinte tabela, usando for’s encadeados:
1
2 4
3 6 9
4 8 12 16
….
n n*2 n*3 …. n*n*/

import java.util.Scanner;

public class TabelaMultiplicacaoNr9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o valor de n: ");
        int n = scanner.nextInt();

        // Loop para cada linha
        for (int i = 1; i <= n; i++) {
            // Loop para cada coluna (múltiplo de i)
            for (int j = 1; j <= i; j++) {
                System.out.print(i * j + " "); // Imprime o múltiplo na mesma linha
            }
            System.out.println(); // Move para a próxima linha após imprimir todos os múltiplos da linha atual
        }

        scanner.close();
    }
}

