import java.util.Random;

public class NumeroAleat {
    public static void main(String[] args) {
        // Cria uma instância da classe Random
        Random random = new Random(System.in);
		
		System.out.println("Digite um numero: ");
		int n = random.nextInt();

        // Gera um número aleatório entre 0 e n
        int randomNumber = random.nextInt(0,n);
        System.out.println("Número aleatório entre 0 e :"+n+" é" + randomNumber);
    }
}