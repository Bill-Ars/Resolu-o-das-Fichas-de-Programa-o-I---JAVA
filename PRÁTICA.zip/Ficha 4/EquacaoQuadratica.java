//Elabore um programa que determina as raízes de uma equação quadrática.


import java.util.Scanner;

public class EquacaoQuadratica {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a; // Declaração da variável a

        // Solicita o coeficiente a ao usuário
        do {
            System.out.print("Digite o coeficiente a (diferente de 0): ");
            a = scanner.nextDouble();
        } while (a == 0); // Continua solicitando enquanto a for igual a 0

        // Solicita os coeficientes b e c
        System.out.print("Digite o coeficiente b: ");
        double b = scanner.nextDouble();

        System.out.print("Digite o coeficiente c: ");
        double c = scanner.nextDouble();

        // Calcula o discriminante
        double discriminante = Math.pow(b, 2) - 4 * a * c;

        // Verifica o valor do discriminante
        if (discriminante > 0) {
            // Duas raízes reais e diferentes
            double raiz1 = (-b + Math.sqrt(discriminante)) / (2 * a);
            double raiz2 = (-b - Math.sqrt(discriminante)) / (2 * a);
            System.out.println("As raízes da equação são: " + raiz1 + " e " + raiz2);
        } else if (discriminante == 0) {
            // Uma raiz real (raízes iguais)
            double raiz = -b / (2 * a);
            System.out.println("A raiz da equação é: " + raiz);
        } else {
            // Sem raízes reais
            System.out.println("A equação não possui raízes reais.");
        }

        // Fecha o scanner
        scanner.close();
    }
}