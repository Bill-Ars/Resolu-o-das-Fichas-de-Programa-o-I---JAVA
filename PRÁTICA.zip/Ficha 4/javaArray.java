import java.util.Arrays;

public class javaArray{
    public static void main(String[] args) {
	
	double Soma = 0;
	int contador = 0;
	
	int V[] = {2,4,6,8,10,16};
	
	for(int i =0;i < V.length;i++){
	
	Soma +=V[i];
	}
	double Media = Soma/contador;
	
	System.out.println(Media);
	}
}
	