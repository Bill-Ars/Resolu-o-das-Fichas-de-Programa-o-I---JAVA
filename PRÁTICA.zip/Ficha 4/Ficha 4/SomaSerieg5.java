//𝐸 = 0 + 1 + 4 + 9 + 16 + 25 + 36 + ⋯



import java.util.Scanner;

public class SomaSerieg5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
		// Solicita ao usuário o número de termos
        System.out.print("Digite o valor de N: ");
        int N = scanner.nextInt();
		
		int i = 0;
		int Soma = 0;
		
		do {
			Soma += Math.pow(i, 2); // Soma o quadrado de i
			i++; // Incrementa i após a soma
		} while (i <= N);
		
		System.out.println("A soma: " + Soma);
		
		scanner.close(); // Fecha o scanner para liberar recursos
    }
}