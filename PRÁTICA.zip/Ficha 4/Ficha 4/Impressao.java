public class ImprimeNumeros {
    public static void main(String[] args) {
        // Loop para imprimir todos os números de 150 a 300
        for (int i = 150; i <= 300; i++) {
            System.out.println(i); // Imprime o número atual
        }
    }
}