/*Escreva um programa que pergunte ao usuário um número e após, imprima na tela a soma 
total de 1 até o número lido. Exemplo: 5: 1 + 2 + 3 + 4 + 5 = 15*/

import java.util.Scanner;

public class ImpressaoNumero{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário o número 
        System.out.print("Digite o numero: ");
        int n = scanner.nextInt();
		
		int Soma=0;
		
		for(int i=1;i<=n;i++){
		Soma +=i;
		}
		
		System.out.println("A soma dos numeros de 1 ate ao numero lido e: "+Soma);
	}
}