import java.util.Scanner;

public class SomaSerie3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário o número de termos
        System.out.print("Digite o número de termos da série: ");
        int n = scanner.nextInt();
        
        // Inicializa a soma
        double soma = 0;

        // Loop para calcular a soma dos termos
        for (int i = 0; i < n; i++) {
            double termo = 1.0 / Math.pow(2, i); // Calcula 1/(2^i)
            soma += termo; // Adiciona o termo à soma
        }

        // Exibe o resultado da soma
        System.out.println("A soma da série é: " + soma);
        
        scanner.close(); // Fecha o scanner para liberar recursos
    }
}