import java.util.Scanner;

public class TabelaMultiplicacao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o valor de n: ");
        int n = scanner.nextInt();

        // Loop para cada linha
        for (int i = 1; i <= n; i++) {
            // Loop para cada coluna (múltiplo de i)
			
            for (int j = 1; j <= i; j++) {
              int Prod = i*j;
			  System.out.println(Prod);
            }
            
        }

      
    }
}