/*Escreva um programa que imprima na tela a soma dos números ímpares entre 0 e 30 e a 
multiplicação dos números pares entre 0 e 30.*/

public class SomaEProduto {
    public static void main(String[] args) {
        int somaImpares = 0;
        int produtoPares = 1; // Inicializa como 1 para multiplicação

        // Calcula a soma dos números ímpares
        for (int i = 1; i < 30; i += 2) {
            somaImpares += i; // Adiciona o número ímpar à soma
        }

        // Calcula a multiplicação dos números pares
        for (int i = 0; i <= 30; i += 2) {
            produtoPares *= i; // Multiplica o número par ao produto
        }

        // Exibe os resultados
        System.out.println("A soma dos números ímpares entre 0 e 30 é: " + somaImpares);
        System.out.println("A multiplicação dos números pares entre 0 e 30 é: " + produtoPares);
    }
}