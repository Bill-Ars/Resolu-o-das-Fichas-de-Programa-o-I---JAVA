/*Escreva um programa que pergunte ao usuário um número e após, imprima na tela a soma 
total de 1 até o número lido. Exemplo: 5: 1 + 2 + 3 + 4 + 5 = 15*/

import java.util.Scanner;

public class BasExpoente{
    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Insira a base: ");
		int base = scanner.nextInt();
		
		System.out.print("Insira o expoente: ");
		int exp = scanner.nextInt();
		int i;
		
		int P=1;
		
		for(i=1;i<=exp;i++){
			P = P*base;
			}
			
		System.out.println("Resultado: "+P);
	}
}
