//  𝐸 = 4 + 16 + 36 + 64 + ⋯

import java.util.Scanner;

public class SomaParesQuad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário o número de termos
        System.out.print("Digite o valor de N: ");
        int N = scanner.nextInt();
		
		int i = 2;
		int Soma = 0;
		
		do {
			Soma += Math.pow(i,2);
			i ++;
		}while (i<=N);
		
		System.out.println(Soma);
	}
}
		