import java.util.Scanner;

public class QuadradoAsteriscos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário que insira o valor de n
        System.out.print("Digite o valor de n (tamanho do lado do quadrado): ");
        int n = scanner.nextInt();

        // Loop para imprimir o quadrado
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print("* "); // Imprime um asterisco seguido de um espaço
            }
            System.out.println(); // Move para a próxima linha após imprimir uma linha do quadrado
        }

        scanner.close(); // Fecha o scanner
    }
}