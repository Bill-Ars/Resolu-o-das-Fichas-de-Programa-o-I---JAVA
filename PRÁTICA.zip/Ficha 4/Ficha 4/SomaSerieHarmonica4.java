import java.util.Scanner;

public class SomaSerieHarmonica4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário o número de termos
        System.out.print("Digite o valor de N: ");
        int N = scanner.nextInt();
        
        // Inicializa a soma
        double soma = 0;

        // Loop para calcular a soma dos termos da série
        for (int i = 1; i <= N; i++) {
            soma += 1.0 / i; // Adiciona 1/i à soma
        }

        // Exibe o resultado da soma
        System.out.println("A soma da série é: " + soma);
        
        scanner.close(); // Fecha o scanner para liberar recursos
    }
}