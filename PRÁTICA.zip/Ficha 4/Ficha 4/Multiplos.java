public class Multiplos{
    public static void main(String[] args) {
        // Loop para imprimir todos os números de 150 a 300
        for (int i = 1; i <= 100; i++) {
		if(i % 3 == 0){
		System.out.println(i); // Imprime o multiplo
		}
            
        }
    }
}