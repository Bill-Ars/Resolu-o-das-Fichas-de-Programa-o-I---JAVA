/*Faça um programa que peça para n pessoas a sua idade, ao final o programa devera verificar se a 
média de idade da turma varia entre 0 e 25,26 e 60 e maior que 60; e então, dizer se a turma é 
jovem, adulta ou idosa, conforme a média calculada.*/

import java.util.Scanner;

public class Idades{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário a quantidade de números
        System.out.print("Digite a quantidade de pessoas: ");
        int N = scanner.nextInt();
		int Soma = 0;
		
		for(int i=1; i<=N;i++){
			System.out.println("Insira idade " +i+ ":");
			int Id = scanner.nextInt();
			Soma +=Id;
		}
		
		double Media = Soma/N;
		
		System.out.println("Media das idades: "+Media);
		
		if(Media>0 && Media <25){
			System.out.println("A turma e jovem");
		}else{
			if(Media>26 && Media <60){
				System.out.println("A turma e adulta");
			}else{
			System.out.println("A turma e idosa");	
			}
		}
		
	}
}