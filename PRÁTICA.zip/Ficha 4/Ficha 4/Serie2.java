/* 𝐸 = 1 + 2 + 4 + 8 + ⋯
*/
import java.util.Scanner;

public class Serie2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o valor de n para a série: ");
        int n = scanner.nextInt();
		
		int i = 1;
		int E = 1;
		
		do{
			i = 2*i;
			E = E + i;
		}while(i<=n);
		
		System.out.println(E);
	}
}