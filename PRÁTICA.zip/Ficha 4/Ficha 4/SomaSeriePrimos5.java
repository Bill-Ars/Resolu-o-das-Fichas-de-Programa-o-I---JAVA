 //𝐸 = 1 + 3 + 5 + 7 + 9 + ⋯
 
 import java.util.Scanner;

public class SomaSeriePrimos5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário o número de termos
        System.out.print("Digite o valor de N: ");
        int N = scanner.nextInt();
		
		int Soma = 0;
		int i = 1;
		
		do{
			Soma = Soma + (2*i+1);
			
			i++;
			
		}while (i<=N);
		
		System.out.println(Soma);
	}
}
		
		
