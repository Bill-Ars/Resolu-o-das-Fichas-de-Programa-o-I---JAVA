/*Faça um programa que, dado um conjunto de N números, determine o menor valor, o 
maior valor e a soma dos valores.*/

import java.util.Scanner;

public class MinMaxSoma {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário a quantidade de números
        System.out.print("Digite a quantidade de números: ");
        int N = scanner.nextInt();

        // Verifica se N é válido
        if (N <= 0) {
            System.out.println("A quantidade de números deve ser maior que zero.");
            return;
        }

        // Inicializa as variáveis
        int menor = 0; // Inicializa com 0
        int maior = 0; // Inicializa com 0
        int soma = 0;  // Variável para armazenar a soma

        // Loop para ler os N números
        for (int i = 1; i <= N; i++) {
            System.out.print("Digite o número " + i + ": ");
            int numero = scanner.nextInt();

            // Para o primeiro número, inicializa menor e maior
            if (i == 1) {
                menor = numero;
                maior = numero;
            } else {
                // Atualiza o menor e o maior valor
                if (menor<numero) {
                    menor = numero;
                }
                if (numero > maior) {
                    maior = numero;
                }
            }

            // Adiciona o número à soma
            soma += numero;
        }

        // Exibe os resultados
        System.out.println("Menor valor: " + menor);
        System.out.println("Maior valor: " + maior);
        System.out.println("Soma dos valores: " + soma);

        scanner.close(); // Fecha o scanner
    }
}