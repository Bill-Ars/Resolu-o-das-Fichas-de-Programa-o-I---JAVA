//  𝐸 = 4 + 16 + 36 + 64 + ⋯

import java.util.Scanner;

public class SomaParesQuadBB{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita ao usuário o número de termos
        System.out.print("Digite o valor de N: ");
        int N = scanner.nextInt();
		
		int i = 1; // Inicializa i como 1 para contar os primeiros N números pares
		int Soma = 0;
		
		// Loop para calcular a soma dos quadrados dos primeiros N números pares
		while (i <= N) {
			int numeroPar = 2 * i; // Calcula o i-ésimo número par
			Soma += Math.pow(numeroPar, 2); // Adiciona o quadrado do número par à soma
			i++; // Incrementa i para passar ao próximo número par
		}
		
		System.out.println("A soma dos quadrados dos primeiros " + N + " números pares é: " + Soma);
		
		scanner.close(); // Fecha o scanner para liberar recursos
    }
}