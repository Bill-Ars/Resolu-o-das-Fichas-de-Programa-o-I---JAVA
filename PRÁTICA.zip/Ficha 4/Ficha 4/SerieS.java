import java.util.Scanner;

public class SerieS {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o valor de n para a série S: ");
        int n = scanner.nextInt();
		
        int i = 1;
        double S = 0.0;
        do{
            int m = 2 * i - 1; // m é o número ímpar correspondente
            S += (double) i / m;
			i++;
        }while(i<=n);

        System.out.printf("O valor da série S é: %.4f%n", S);
        scanner.close();
    }
}