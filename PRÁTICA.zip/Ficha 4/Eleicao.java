import java.util.Scanner;

public class Eleicao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicita o número total de eleitores
        System.out.print("Digite o número total de eleitores: ");
        int totalEleitores = scanner.nextInt();
        
        // Inicializa os contadores de votos para cada candidato
        int votosCandidato1 = 0;
        int votosCandidato2 = 0;
        int votosCandidato3 = 0;

        // Loop para coletar os votos de cada eleitor
        for (int i = 1; i <= totalEleitores; i++) {
            System.out.println("Eleitor " + i + ", vote em um dos candidatos:");
            System.out.println("1 - Candidato 1");
            System.out.println("2 - Candidato 2");
            System.out.println("3 - Candidato 3");
            System.out.print("Digite o número do candidato: ");
            int voto = scanner.nextInt();

            // Verifica qual candidato foi votado e incrementa o contador correspondente
            switch (voto) {
                case 1:
                    votosCandidato1++;
                    break;
                case 2:
                    votosCandidato2++;
                    break;
                case 3:
                    votosCandidato3++;
                    break;
                default:
                    System.out.println("Voto inválido! Por favor, vote novamente.");
                    break;
            }
        }

        // Exibe o resultado da eleição
        System.out.println("\nResultado da eleição:");
        System.out.println("Candidato 1: " + votosCandidato1 + " votos");
        System.out.println("Candidato 2: " + votosCandidato2 + " votos");
        System.out.println("Candidato 3: " + votosCandidato3 + " votos");

        scanner.close(); // Fecha o scanner para liberar recursos
    }
}