public class FloorExample {
    public static void main(String[] args) {
        // Exemplos de uso do Math.floor()
        double num1 = 3.8;
        double num2 = 2.1;
        double num3 = -2.1;
        double num4 = 5.0;
        double num5 = -5.9;

        System.out.println("Math.floor(" + num1 + ") = " + Math.floor(num1)); // Saída: 3.0
        System.out.println("Math.floor(" + num2 + ") = " + Math.floor(num2)); // Saída: 2.0
        System.out.println("Math.floor(" + num3 + ") = " + Math.floor(num3)); // Saída: -3.0
        System.out.println("Math.floor(" + num4 + ") = " + Math.floor(num4)); // Saída: 5.0
        System.out.println("Math.floor(" + num5 + ") = " + Math.floor(num5)); // Saída: -6.0
    }
}