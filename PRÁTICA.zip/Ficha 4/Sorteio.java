//Crie uma classe que gere 5 cartões de loteria com seis números em cada um.

import java.util.Scanner;

public class Sorteio {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Sorteia um número entre 0 e 1000
        int numeroSorteado = (int) (Math.random() * 1001); // Gera um número entre 0 e 1000
        int palpite;
        int tentativas = 0; // Contador de tentativas

        System.out.println("Bem-vindo ao jogo de adivinhação!");
        System.out.println("Tente adivinhar o número que foi sorteado entre 0 e 1000.");

        // Loop para pedir palpites até acertar
        do {
            System.out.print("Digite seu palpite: ");
            palpite = scanner.nextInt(); // Lê o palpite do usuário
            tentativas++; // Incrementa o contador de tentativas

            if (palpite < numeroSorteado) {
                System.out.println("Seu palpite é menor que o número sorteado.");
            } else if (palpite > numeroSorteado) {
                System.out.println("Seu palpite é maior que o número sorteado.");
            } else {
                System.out.println("Parabéns! Você acertou o número sorteado: " + numeroSorteado);
            }
        } while (palpite != numeroSorteado); // Continua até acertar

        // Exibe o número de tentativas
        System.out.println("Você acertou em " + tentativas + " tentativas.");

        // Fecha o scanner
        scanner.close();
    }
}