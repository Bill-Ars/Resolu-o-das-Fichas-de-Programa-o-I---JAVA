import java.util.Scanner;

public class DistanciaEntrePontos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Lê as coordenadas do primeiro ponto
        System.out.print("Digite as coordenadas do primeiro ponto (x1 y1): ");
        double x1 = scanner.nextDouble();
        double y1 = scanner.nextDouble();

        // Lê as coordenadas do segundo ponto
        System.out.print("Digite as coordenadas do segundo ponto (x2 y2): ");
        double x2 = scanner.nextDouble();
        double y2 = scanner.nextDouble();

        // Calcula a distância entre os pontos
        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        // Exibe o resultado
        System.out.println("A distância entre os pontos é: " + distancia);

        // Fecha o scanner
        scanner.close();
    }
}