public class ex2{
    public static void main(String[] args) {
        String jav = "Java";
        
        // Parte crescente
        for (int i = 0; i < jav.length(); i++) {
            System.out.println(jav.substring(0, i));
        }
        
        // Parte decrescentej
        for (int i = jav.length() - 1; i > 0; i--) {
            System.out.println(jav.substring(0, i));
        }
		
    }
}