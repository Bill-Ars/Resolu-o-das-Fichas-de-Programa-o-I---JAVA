
/*. Elabore um método em Java que tenha como entrada um número inteiro e forneça como 
saída um conjunto de 15 elementos contendo os seus submúltiplos*/

import java.util.Scanner;

public class SubmultiplosBBNumero12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
	System.out.println("Insira um numero: ");
	double  numero = scanner.nextInt();
	
	int submult [] = new int [15];
	
	int b = 0;
	double cont = 0;
	
		for (int i = 0; i<submult.length; i++){
			
			do{
				b +=1;
				if(numero%b == 0){
					b = submult[i];
					cont ++;
				}
				
				
			}while (cont <= num);
			
			if( cont != 15){
					
					System.out.println("O numero nao tem 15 submultiplos. Insira um numero maior. Obrigado!");
					int  numero = scanner.nextInt();
				}else{
					for (int i = 0; submult.length; i++){
					System.out.println(submult[i]);	
					}
				}
			
			
		}
	
	}	
}