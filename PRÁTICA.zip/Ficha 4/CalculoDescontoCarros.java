import java.util.Scanner;

public class CalculoDescontoCarros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String Continuar;
        int totalCarros = 0;
        int totalCarrosAte2000 = 0;

        do {
            System.out.print("Digite o ano do veículo: ");
            int anoVeiculo = scanner.nextInt();
            System.out.print("Digite o valor do carro: R$ ");
            double valorCarro = scanner.nextDouble();

            double desconto;
            if (anoVeiculo <= 2000) {
                desconto = valorCarro * 0.12; // 12% de desconto
                totalCarrosAte2000++;
            } else {
                desconto = valorCarro * 0.07; // 7% de desconto
            }

            double valorAPagar = valorCarro - desconto;

            // Exibe os resultados
            System.out.printf("Desconto: R$ %.2f%n", desconto);
            System.out.printf("Valor a ser pago: R$ %.2f%n", valorAPagar);

            totalCarros++;

            System.out.print("Deseja calcular o desconto para outro carro? (S para sim / N para não): ");
            Continuar = nextLine();

        } while (!equals("N"));

        // Exibe o total de carros
        System.out.println("Total de carros no geral: " + totalCarros);
        System.out.println("Total de carros com ano até 2000: " + totalCarrosAte2000);

        scanner.close();
    }
}