public class RandomInRange {
    public static void main(String[] args) {
        int min = 1;
        int max = 100;
        int randomValue = (int) (Math.random() * (max - min + 1)) + min;
        System.out.println("Número aleatório entre " + min + " e " + max + ": " + randomValue);
    }
}