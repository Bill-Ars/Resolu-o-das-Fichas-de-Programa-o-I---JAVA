
 /* Crie um programa em que o usuário digite uma palavra com pelo menos 8 caracteres e a 
seguir forme uma nova palavra usando as duas primeiras e as duas últimas letras. Se a 
palavra digitada tiver menos que 8 caracteres, mostre uma mensagem de erro.  */

import java.util.Scanner;

public class EX1_WordTransformer {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite uma palavra com pelo menos 8 caracteres: ");
        String originalWord = scanner.nextLine();
        
        if (originalWord.length() < 8) {
            System.out.println("Erro: A palavra deve ter pelo menos 8 caracteres.");
        } else {
            String newWord = originalWord.substring(0, 2) + originalWord.substring(originalWord.length() - 2);
            System.out.println("Nova palavra: " + newWord);
        }
        
        scanner.close();
    }
}