public class CeilExample {
    public static void main(String[] args) {
        double num1 = 4.2;
        double num2 = 4.8;
        double num3 = -4.2;
        double num4 = -4.8;
        double num5 = 5.0;

        // Usando Math.ceil
        System.out.println("Math.ceil(" + num1 + ") = " + Math.ceil(num1)); // Saída: 5.0
        System.out.println("Math.ceil(" + num2 + ") = " + Math.ceil(num2)); // Saída: 5.0
        System.out.println("Math.ceil(" + num3 + ") = " + Math.ceil(num3)); // Saída: -4.0
        System.out.println("Math.ceil(" + num4 + ") = " + Math.ceil(num4)); // Saída: -4.0
        System.out.println("Math.ceil(" + num5 + ") = " + Math.ceil(num5)); // Saída: 5.0
    }
}